// admin/lib/screens/dashboard/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../services/admin_service.dart';
import '../../utils/theme.dart';
import '../../widgets/admin_widgets.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(statsProvider);
    final logs  = ref.watch(logsProvider);

    return Scaffold(
      backgroundColor: AC.bg,
      appBar: AppBar(title: const Text('Dashboard'), backgroundColor: AC.bg,
          elevation: 0, automaticallyImplyLeading: false),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // Stats grid
          stats.when(
            loading: () => const Center(child: CircularProgressIndicator(color: AC.brand1)),
            error: (e, _) => Text('Error: $e', style: const TextStyle(color: AC.error)),
            data: (s) => GridView.count(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: MediaQuery.of(context).size.width > 700 ? 4 : 2,
              mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.3,
              children: [
                AdminStatCard(value: '${s['total_users'] ?? 0}',       label: 'Usuarios',      icon: Icons.people_alt_rounded,      color: AC.brand1),
                AdminStatCard(value: '${s['total_devices'] ?? 0}',     label: 'Dispositivos',   icon: Icons.bluetooth_rounded,       color: AC.success),
                AdminStatCard(value: '${s['accesses_today'] ?? 0}',    label: 'Accesos hoy',    icon: Icons.door_front_door_rounded, color: AC.brand2),
                AdminStatCard(value: '${s['success_rate_30d'] ?? 0}%', label: 'Tasa éxito 30d', icon: Icons.verified_rounded,        color: AC.success),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Quick actions
          Row(children: [
            const Text('Acceso rápido', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600,
                color: AC.text1, fontFamily: 'SpaceGrotesk')),
          ]),
          const SizedBox(height: 12),
          Wrap(spacing: 10, runSpacing: 10, children: [
            _QuickBtn(Icons.person_add_rounded,   'Nuevo usuario',     () => context.go('/users')),
            _QuickBtn(Icons.add_circle_rounded,   'Nuevo dispositivo', () => context.go('/devices')),
            _QuickBtn(Icons.local_parking_rounded,'Nuevo parking',     () => context.go('/parkings')),
            _QuickBtn(Icons.receipt_long_rounded, 'Ver historial',     () => context.go('/logs')),
          ]),

          const SizedBox(height: 28),

          const Text('Actividad reciente', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600,
              color: AC.text1, fontFamily: 'SpaceGrotesk')),
          const SizedBox(height: 12),

          logs.when(
            loading: () => const Center(child: CircularProgressIndicator(color: AC.brand1)),
            error: (e, _) => AdminEmpty(icon: Icons.history_rounded, title: 'Error al cargar'),
            data: (list) {
              if (list.isEmpty) return const AdminEmpty(icon: Icons.history_rounded, title: 'Sin actividad');
              final recent = list.take(15).toList();
              return AdminCard(
                padding: EdgeInsets.zero,
                child: Column(children: List.generate(recent.length, (i) {
                  final l = recent[i];
                  final ok = l['result'] == 'success';
                  final ts = l['created_at'] != null
                      ? DateFormat('d MMM · HH:mm', 'es').format(DateTime.parse(l['created_at']).toLocal())
                      : '—';
                  return Column(children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      child: Row(children: [
                        Container(width: 7, height: 7, decoration: BoxDecoration(
                          shape: BoxShape.circle, color: ok ? AC.success : AC.error)),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(l['user_name'] ?? l['user_email'] ?? '—',
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500,
                                  color: AC.text1, fontFamily: 'SpaceGrotesk')),
                          Text(l['space_label'] ?? l['space_number'] != null
                              ? 'Plaza ${l['space_number']}' : l['parking_name'] ?? '—',
                              style: const TextStyle(fontSize: 11, color: AC.text3, fontFamily: 'SpaceGrotesk')),
                        ])),
                        Text(ts, style: const TextStyle(fontSize: 11, color: AC.text2, fontFamily: 'SpaceGrotesk')),
                      ]),
                    ),
                    if (i < recent.length - 1) const Divider(height: 1, indent: 16, endIndent: 16),
                  ]);
                })),
              );
            },
          ),
        ]),
      ),
    );
  }
}

class _QuickBtn extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _QuickBtn(this.icon, this.label, this.onTap);

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(10),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(color: AC.surface, borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AC.border)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 16, color: AC.brand1),
        const SizedBox(width: 8),
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500,
            color: AC.text1, fontFamily: 'SpaceGrotesk')),
      ]),
    ),
  );
}
