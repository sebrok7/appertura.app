// lib/models/models.dart

const String _bleDevicePrefix = 'APARKAO_';

class UserProfile {
  final String id;
  final String email;
  final String? fullName;
  final String? phone;
  final String? avatarUrl;
  final String role;
  final String? communityId;
  final bool isActive;
  final DateTime? lastLoginAt;
  final DateTime createdAt;

  const UserProfile({
    required this.id, required this.email, this.fullName, this.phone,
    this.avatarUrl, required this.role, this.communityId,
    required this.isActive, this.lastLoginAt, required this.createdAt,
  });

  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
    id: j['id'], email: j['email'], fullName: j['full_name'],
    phone: j['phone'], avatarUrl: j['avatar_url'],
    role: j['role'] ?? 'resident', communityId: j['community_id'],
    isActive: j['is_active'] ?? true,
    lastLoginAt: j['last_login_at'] != null ? DateTime.parse(j['last_login_at']) : null,
    createdAt: DateTime.parse(j['created_at']),
  );

  bool get isAdmin => role == 'admin' || role == 'super_admin';
  bool get isSuperAdmin => role == 'super_admin';
  String get displayName => (fullName?.isNotEmpty == true) ? fullName! : email.split('@').first;
  String get initials {
    if (fullName == null || fullName!.isEmpty) return email[0].toUpperCase();
    final parts = fullName!.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return parts[0][0].toUpperCase();
  }
}

class Community {
  final String id;
  final String name;
  final String? address;
  final String? city;
  final bool isActive;

  const Community({required this.id, required this.name, this.address, this.city, required this.isActive});

  factory Community.fromJson(Map<String, dynamic> j) => Community(
    id: j['id'], name: j['name'], address: j['address'],
    city: j['city'], isActive: j['is_active'] ?? true,
  );
}

class ParkingDevice {
  final String deviceUuid;
  final String deviceHwId;
  final String? bleName;
  final int relayPulseMs;
  final bool deviceActive;
  final DateTime? lastSeenAt;
  final String? spaceNumber;
  final String? spaceLabel;
  final String? parkingId;
  final String? parkingName;
  final String? communityId;
  final String? communityName;

  const ParkingDevice({
    required this.deviceUuid, required this.deviceHwId,
    this.bleName, required this.relayPulseMs, required this.deviceActive,
    this.lastSeenAt, this.spaceNumber, this.spaceLabel,
    this.parkingId, this.parkingName, this.communityId, this.communityName,
  });

  factory ParkingDevice.fromJson(Map<String, dynamic> j) => ParkingDevice(
    deviceUuid: j['device_uuid'], deviceHwId: j['device_hw_id'],
    bleName: j['ble_name'], relayPulseMs: j['relay_pulse_ms'] ?? 500,
    deviceActive: j['device_active'] ?? true,
    lastSeenAt: j['last_seen_at'] != null ? DateTime.parse(j['last_seen_at']) : null,
    spaceNumber: j['space_number'], spaceLabel: j['space_label'],
    parkingId: j['parking_id'], parkingName: j['parking_name'],
    communityId: j['community_id'], communityName: j['community_name'],
  );

  factory ParkingDevice.fromDeviceJson(Map<String, dynamic> j) => ParkingDevice(
    deviceUuid: j['id'], deviceHwId: j['device_id'],
    bleName: j['ble_name'], relayPulseMs: j['relay_pulse_ms'] ?? 500,
    deviceActive: j['is_active'] ?? true,
    lastSeenAt: j['last_seen_at'] != null ? DateTime.parse(j['last_seen_at']) : null,
    spaceNumber: j['parking_spaces']?['number'],
    spaceLabel: j['parking_spaces']?['label'],
    parkingId: j['parking_spaces']?['parking_id'],
    parkingName: j['parking_spaces']?['parkings']?['name'],
  );

  String get displayName {
    if (spaceLabel?.isNotEmpty == true) return spaceLabel!;
    if (spaceNumber?.isNotEmpty == true) return 'Plaza $spaceNumber';
    return 'Dispositivo $deviceHwId';
  }

  String get effectiveBleName => bleName ?? '${_bleDevicePrefix}$deviceHwId';
}

class DevicePermission {
  final String permissionId;
  final String userId;
  final String deviceId;
  final String permissionType;
  final DateTime? validFrom;
  final DateTime? validUntil;
  final int? maxUses;
  final int usesCount;
  final bool permissionActive;
  final ParkingDevice? device;

  const DevicePermission({
    required this.permissionId, required this.userId, required this.deviceId,
    required this.permissionType, this.validFrom, this.validUntil,
    this.maxUses, required this.usesCount, required this.permissionActive, this.device,
  });

  factory DevicePermission.fromView(Map<String, dynamic> j) => DevicePermission(
    permissionId: j['permission_id'], userId: j['user_id'],
    deviceId: j['device_uuid'], permissionType: j['permission_type'] ?? 'permanent',
    validFrom: j['valid_from'] != null ? DateTime.parse(j['valid_from']) : null,
    validUntil: j['valid_until'] != null ? DateTime.parse(j['valid_until']) : null,
    maxUses: j['max_uses'], usesCount: j['uses_count'] ?? 0,
    permissionActive: j['permission_active'] ?? true,
    device: ParkingDevice.fromJson(j),
  );

  bool get isExpired => validUntil != null && validUntil!.isBefore(DateTime.now());
  bool get isExhausted => maxUses != null && usesCount >= maxUses!;
  bool get canAccess => permissionActive && !isExpired && !isExhausted;

  String get typeLabel => switch (permissionType) {
    'permanent' => 'Permanente',
    'temporary' => 'Temporal',
    'invitation' => 'Invitación',
    _ => permissionType,
  };
}

class AccessLog {
  final String id;
  final String result;
  final String? errorCode;
  final int? bleRssi;
  final String accessMethod;
  final DateTime createdAt;
  final String? userName;
  final String? userEmail;
  final String? deviceHwId;
  final String? spaceNumber;
  final String? spaceLabel;
  final String? parkingName;
  final String? communityName;

  const AccessLog({
    required this.id, required this.result, this.errorCode, this.bleRssi,
    required this.accessMethod, required this.createdAt, this.userName,
    this.userEmail, this.deviceHwId, this.spaceNumber, this.spaceLabel,
    this.parkingName, this.communityName,
  });

  factory AccessLog.fromJson(Map<String, dynamic> j) => AccessLog(
    id: j['id'], result: j['result'], errorCode: j['error_code'],
    bleRssi: j['ble_rssi'], accessMethod: j['access_method'] ?? 'ble',
    createdAt: DateTime.parse(j['created_at']),
    userName: j['user_name'], userEmail: j['user_email'],
    deviceHwId: j['device_hw_id'], spaceNumber: j['space_number'],
    spaceLabel: j['space_label'], parkingName: j['parking_name'],
    communityName: j['community_name'],
  );

  bool get isSuccess => result == 'success';

  String get resultLabel => switch (result) {
    'success' => 'Apertura correcta',
    'denied'  => 'Sin permisos',
    'error'   => 'Error técnico',
    'timeout' => 'Tiempo agotado',
    _ => result,
  };

  String get locationLabel {
    if (spaceLabel?.isNotEmpty == true) return spaceLabel!;
    if (spaceNumber?.isNotEmpty == true) return 'Plaza $spaceNumber';
    if (parkingName?.isNotEmpty == true) return parkingName!;
    return deviceHwId ?? '—';
  }
}

class BleTokenResult {
  final String token;
  final String tokenId;
  final DateTime expiresAt;
  final int relayPulseMs;

  const BleTokenResult({
    required this.token, required this.tokenId,
    required this.expiresAt, required this.relayPulseMs,
  });

  factory BleTokenResult.fromJson(Map<String, dynamic> j) => BleTokenResult(
    token: j['token'], tokenId: j['token_id'],
    expiresAt: DateTime.parse(j['expires_at']),
    relayPulseMs: j['relay_pulse_ms'] ?? 500,
  );

  bool get isExpired => expiresAt.isBefore(DateTime.now());
}

class AdminStats {
  final int totalUsers;
  final int totalDevices;
  final int accessesToday;
  final int accessesMonth;
  final double successRate30d;
  final int activePermissions;

  const AdminStats({
    required this.totalUsers, required this.totalDevices,
    required this.accessesToday, required this.accessesMonth,
    required this.successRate30d, required this.activePermissions,
  });

  factory AdminStats.fromJson(Map<String, dynamic> j) => AdminStats(
    totalUsers: j['total_users'] ?? 0,
    totalDevices: j['total_devices'] ?? 0,
    accessesToday: j['accesses_today'] ?? 0,
    accessesMonth: j['accesses_month'] ?? 0,
    successRate30d: (j['success_rate_30d'] ?? 0).toDouble(),
    activePermissions: j['active_permissions'] ?? 0,
  );
}

enum OpenDoorState {
  idle, checkingPermission, scanningBle,
  connecting, authenticating, activatingRelay,
  success, error,
}

enum OpenDoorError {
  noPermission, deviceNotFound, connectionFailed,
  authFailed, relayError, timeout, bleDisabled, unknown,
}
