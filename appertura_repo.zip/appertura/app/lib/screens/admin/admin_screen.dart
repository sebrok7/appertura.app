// lib/screens/admin/admin_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../models/models.dart';
import '../../services/supabase_service.dart';
import '../../utils/constants.dart';
import '../../widgets/widgets.dart';

// ── providers ─────────────────────────────────────────────────
final _statsProvider = FutureProvider<AdminStats>((ref) =>
    ref.read(supabaseServiceProvider).getAdminStats());

final _usersProvider = FutureProvider<List<UserProfile>>((ref) =>
    ref.read(supabaseServiceProvider).getAllUsers());

final _devicesProvider = FutureProvider<List<ParkingDevice>>((ref) =>
    ref.read(supabaseServiceProvider).getAllDevices());

final _logsProvider = FutureProvider<List<AccessLog>>((ref) =>
    ref.read(supabaseServiceProvider).getAllLogs(limit: 200));

// ═══════════════════════════════════════════════════════════════
// ADMIN DASHBOARD
// ═══════════════════════════════════════════════════════════════
class AdminDashboardScreen extends ConsumerWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: appBar('Panel Admin', actions: [
        IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () {
          ref.invalidate(_statsProvider);
          ref.invalidate(_logsProvider);
        }),
        IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => context.go('/home')),
      ]),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(Sp.lg),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          const Text('Resumen', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600,
              color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
          const SizedBox(height: Sp.md),

          // Stats grid
          ref.watch(_statsProvider).when(
            loading: () => const SizedBox(height: 160,
                child: Center(child: CircularProgressIndicator(color: AppColors.brand1))),
            error: (_, __) => const SizedBox.shrink(),
            data: (s) => GridView.count(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10,
              childAspectRatio: 1.35,
              children: [
                StatCard(value: '${s.totalUsers}',        label: 'Usuarios',          icon: Icons.people_rounded,        color: AppColors.brand1),
                StatCard(value: '${s.totalDevices}',      label: 'Dispositivos',       icon: Icons.bluetooth_rounded,     color: AppColors.success),
                StatCard(value: '${s.accessesToday}',     label: 'Accesos hoy',        icon: Icons.door_front_door_rounded,color: AppColors.brand2),
                StatCard(value: '${s.successRate30d}%',   label: 'Tasa éxito 30d',     icon: Icons.verified_rounded,      color: AppColors.success),
              ],
            ),
          ),

          const SizedBox(height: Sp.xl),

          const Text('Gestión', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600,
              color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
          const SizedBox(height: Sp.md),

          Row(children: [
            _ActionTile(Icons.people_alt_rounded,  'Usuarios',    () => context.push('/admin/users')),
            const SizedBox(width: 10),
            _ActionTile(Icons.device_hub_rounded,   'Dispositivos', () => context.push('/admin/devices')),
            const SizedBox(width: 10),
            _ActionTile(Icons.receipt_long_rounded, 'Historial',   () => context.push('/admin/logs')),
          ]),

          const SizedBox(height: Sp.xl),

          const Text('Actividad reciente', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600,
              color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
          const SizedBox(height: Sp.md),

          ref.watch(_logsProvider).when(
            loading: () => const Center(child: CircularProgressIndicator(color: AppColors.brand1)),
            error: (_, __) => const SizedBox.shrink(),
            data: (logs) {
              if (logs.isEmpty) return const EmptyState(icon: Icons.history_rounded, title: 'Sin actividad');
              final recent = logs.take(10).toList();
              return AppCard(
                padding: EdgeInsets.zero,
                child: Column(children: List.generate(recent.length, (i) {
                  final l = recent[i];
                  return Column(children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: Sp.md, vertical: 10),
                      child: Row(children: [
                        Container(width: 8, height: 8,
                            decoration: BoxDecoration(shape: BoxShape.circle,
                                color: l.isSuccess ? AppColors.success : AppColors.error)),
                        const SizedBox(width: Sp.sm),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(l.userName ?? l.userEmail ?? '—',
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500,
                                  color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                          Text(l.locationLabel,
                              style: const TextStyle(fontSize: 11, color: AppColors.textMuted,
                                  fontFamily: 'SpaceGrotesk')),
                        ])),
                        Text(DateFormat('HH:mm  d MMM').format(l.createdAt.toLocal()),
                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary,
                                fontFamily: 'SpaceGrotesk')),
                      ]),
                    ),
                    if (i < recent.length - 1) const Divider(height: 1, indent: 16, endIndent: 16),
                  ]);
                })),
              );
            },
          ),

          const SizedBox(height: Sp.xxl),
        ]),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _ActionTile(this.icon, this.label, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: Sp.md),
        decoration: BoxDecoration(color: AppColors.surface,
            borderRadius: BorderRadius.circular(Rx.lg),
            border: Border.all(color: AppColors.border)),
        child: Column(children: [
          Icon(icon, color: AppColors.brand1, size: 26),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary,
              fontWeight: FontWeight.w500, fontFamily: 'SpaceGrotesk')),
        ]),
      ),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════
// ADMIN USERS
// ═══════════════════════════════════════════════════════════════
class AdminUsersScreen extends ConsumerStatefulWidget {
  const AdminUsersScreen({super.key});
  @override ConsumerState<AdminUsersScreen> createState() => _AdminUsersState();
}

class _AdminUsersState extends ConsumerState<AdminUsersScreen> {
  List<UserProfile> _users = [];
  bool _loading = true;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    _users = await ref.read(supabaseServiceProvider).getAllUsers();
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _suspend(UserProfile u) async {
    final ctrl = TextEditingController();
    final reason = await showDialog<String>(context: context,
        builder: (_) => AlertDialog(
          backgroundColor: AppColors.surface,
          title: const Text('Motivo de suspensión', style: TextStyle(color: AppColors.textPrimary)),
          content: TextField(controller: ctrl,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(hintText: 'Introduce el motivo...')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
            ElevatedButton(onPressed: () => Navigator.pop(context, ctrl.text),
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.brand1),
                child: const Text('Confirmar')),
          ],
        ));
    if (reason == null) return;
    await ref.read(supabaseServiceProvider).suspendUser(u.id, reason);
    _load();
  }

  Future<void> _addUser() async {
    final name  = TextEditingController();
    final email = TextEditingController();
    final pass  = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: AppColors.surface,
      title: const Text('Nuevo usuario', style: TextStyle(color: AppColors.textPrimary)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        AppField(label: 'Nombre', controller: name, prefixIcon: Icons.person_outline),
        const SizedBox(height: Sp.sm),
        AppField(label: 'Email', controller: email, prefixIcon: Icons.email_outlined,
            keyboardType: TextInputType.emailAddress),
        const SizedBox(height: Sp.sm),
        AppField(label: 'Contraseña', controller: pass, obscure: true,
            prefixIcon: Icons.lock_outline),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.brand1),
          onPressed: () async {
            if (name.text.isEmpty || email.text.isEmpty || pass.text.isEmpty) return;
            try {
              await ref.read(supabaseServiceProvider).createUser(
                  email.text.trim(), pass.text, name.text.trim());
              if (mounted) Navigator.pop(context);
              _load();
            } catch (e) {
              if (mounted) ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
            }
          },
          child: const Text('Crear'),
        ),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: appBar('Usuarios', actions: [
      IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _load),
      IconButton(icon: const Icon(Icons.person_add_rounded), onPressed: _addUser),
    ]),
    body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppColors.brand1))
        : _users.isEmpty
            ? EmptyState(icon: Icons.people_outline, title: 'Sin usuarios',
                action: ElevatedButton.icon(
                    onPressed: _addUser,
                    icon: const Icon(Icons.add), label: const Text('Añadir usuario'),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.brand1)))
            : ListView.separated(
                padding: const EdgeInsets.all(Sp.lg),
                itemCount: _users.length,
                separatorBuilder: (_, __) => const SizedBox(height: Sp.sm),
                itemBuilder: (_, i) {
                  final u = _users[i];
                  return AppCard(
                    child: Row(children: [
                      AppAvatar(initials: u.initials, size: 42, isAdmin: u.isAdmin),
                      const SizedBox(width: Sp.md),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(u.displayName, style: const TextStyle(fontSize: 14,
                            fontWeight: FontWeight.w500, color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                        Text(u.email, style: const TextStyle(fontSize: 12,
                            color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
                      ])),
                      StatusChip(
                        label: u.isActive ? u.role : 'Suspendido',
                        color: u.isActive ? (u.isAdmin ? AppColors.brand1 : AppColors.success) : AppColors.error,
                      ),
                      const SizedBox(width: Sp.sm),
                      PopupMenuButton<String>(
                        color: AppColors.surface2,
                        icon: const Icon(Icons.more_vert_rounded, color: AppColors.textMuted, size: 18),
                        onSelected: (a) async {
                          if (a == 'suspend') await _suspend(u);
                          if (a == 'reactivate') {
                            await ref.read(supabaseServiceProvider).reactivateUser(u.id);
                            _load();
                          }
                        },
                        itemBuilder: (_) => [
                          if (u.isActive)
                            const PopupMenuItem(value: 'suspend',
                                child: Text('Suspender', style: TextStyle(color: AppColors.error)))
                          else
                            const PopupMenuItem(value: 'reactivate',
                                child: Text('Reactivar', style: TextStyle(color: AppColors.success))),
                        ],
                      ),
                    ]),
                  );
                },
              ),
  );
}

// ═══════════════════════════════════════════════════════════════
// ADMIN DEVICES
// ═══════════════════════════════════════════════════════════════
class AdminDevicesScreen extends ConsumerStatefulWidget {
  const AdminDevicesScreen({super.key});
  @override ConsumerState<AdminDevicesScreen> createState() => _AdminDevicesState();
}

class _AdminDevicesState extends ConsumerState<AdminDevicesScreen> {
  List<ParkingDevice> _devices = [];
  bool _loading = true;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    _devices = await ref.read(supabaseServiceProvider).getAllDevices();
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _addDevice() async {
    final deviceId  = TextEditingController();
    final bleName   = TextEditingController();
    final spotNum   = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: AppColors.surface,
      title: const Text('Nuevo dispositivo', style: TextStyle(color: AppColors.textPrimary)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        AppField(label: 'Device ID *', controller: deviceId,
            prefixIcon: Icons.fingerprint_rounded, hint: 'ID del hardware'),
        const SizedBox(height: Sp.sm),
        AppField(label: 'Nombre BLE', controller: bleName,
            prefixIcon: Icons.bluetooth_rounded, hint: 'APARKAO_XXXX (opcional)'),
        const SizedBox(height: Sp.sm),
        AppField(label: 'Número de plaza', controller: spotNum,
            prefixIcon: Icons.local_parking_rounded),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.brand1),
          onPressed: () async {
            if (deviceId.text.isEmpty) return;
            try {
              await ref.read(supabaseServiceProvider).createDevice(
                deviceId: deviceId.text.trim(),
                bleName: bleName.text.isNotEmpty ? bleName.text.trim() : null,
              );
              if (mounted) Navigator.pop(context);
              _load();
            } catch (e) {
              if (mounted) ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('Error: $e')));
            }
          },
          child: const Text('Añadir'),
        ),
      ],
    ));
  }

  Future<void> _managePermissions(ParkingDevice d) async {
    final emailCtrl = TextEditingController();
    await showModalBottomSheet(
      context: context, backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(Sp.lg, Sp.lg, Sp.lg,
            Sp.lg + MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Acceso a ${d.displayName}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
          const SizedBox(height: Sp.lg),
          AppField(label: 'Email del usuario', controller: emailCtrl,
              prefixIcon: Icons.email_outlined, keyboardType: TextInputType.emailAddress),
          const SizedBox(height: Sp.md),
          GradientButton(
            label: 'Conceder acceso permanente',
            onPressed: () async {
              if (emailCtrl.text.isEmpty) return;
              try {
                final users = await ref.read(supabaseServiceProvider).getAllUsers();
                final user = users.firstWhere(
                    (u) => u.email.toLowerCase() == emailCtrl.text.trim().toLowerCase(),
                    orElse: () => throw Exception('Usuario no encontrado'));
                await ref.read(supabaseServiceProvider).grantPermission(
                    userId: user.id, deviceId: d.deviceUuid);
                if (ctx.mounted) Navigator.pop(ctx);
                if (context.mounted)
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Acceso concedido a ${user.displayName}')));
              } catch (e) {
                if (ctx.mounted) ScaffoldMessenger.of(ctx)
                    .showSnackBar(SnackBar(content: Text('Error: $e')));
              }
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: appBar('Dispositivos', actions: [
      IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _load),
      IconButton(icon: const Icon(Icons.add_rounded), onPressed: _addDevice),
    ]),
    body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppColors.brand1))
        : _devices.isEmpty
            ? EmptyState(icon: Icons.device_hub_outlined, title: 'Sin dispositivos',
                action: ElevatedButton.icon(
                    onPressed: _addDevice,
                    icon: const Icon(Icons.add), label: const Text('Añadir dispositivo'),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.brand1)))
            : ListView.separated(
                padding: const EdgeInsets.all(Sp.lg),
                itemCount: _devices.length,
                separatorBuilder: (_, __) => const SizedBox(height: Sp.sm),
                itemBuilder: (_, i) {
                  final d = _devices[i];
                  return AppCard(
                    child: Column(children: [
                      Row(children: [
                        IconBox(
                          icon: Icons.bluetooth_rounded,
                          color: d.deviceActive ? AppColors.brand1 : AppColors.textMuted,
                        ),
                        const SizedBox(width: Sp.md),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(d.displayName, style: const TextStyle(fontSize: 14,
                              fontWeight: FontWeight.w500, color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                          Text(d.effectiveBleName, style: const TextStyle(fontSize: 12,
                              color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
                        ])),
                        StatusChip(
                          label: d.deviceActive ? 'Activo' : 'Baja',
                          color: d.deviceActive ? AppColors.success : AppColors.textMuted,
                        ),
                        const SizedBox(width: Sp.sm),
                        PopupMenuButton<String>(
                          color: AppColors.surface2,
                          icon: const Icon(Icons.more_vert_rounded, color: AppColors.textMuted, size: 18),
                          onSelected: (a) async {
                            if (a == 'perms') await _managePermissions(d);
                            if (a == 'deactivate') {
                              await ref.read(supabaseServiceProvider).deactivateDevice(d.deviceUuid);
                              _load();
                            }
                          },
                          itemBuilder: (_) => [
                            const PopupMenuItem(value: 'perms',
                                child: Text('Gestionar permisos', style: TextStyle(color: AppColors.textPrimary))),
                            const PopupMenuItem(value: 'deactivate',
                                child: Text('Dar de baja', style: TextStyle(color: AppColors.error))),
                          ],
                        ),
                      ]),
                      const SizedBox(height: 8),
                      Divider(height: 1, color: AppColors.border),
                      const SizedBox(height: 6),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Text('ID: ${d.deviceHwId}', style: const TextStyle(fontSize: 11,
                            color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
                        Text(d.lastSeenAt != null
                            ? 'Visto: ${DateFormat("d MMM HH:mm").format(d.lastSeenAt!.toLocal())}'
                            : 'Sin actividad',
                            style: const TextStyle(fontSize: 11, color: AppColors.textMuted,
                                fontFamily: 'SpaceGrotesk')),
                      ]),
                    ]),
                  );
                },
              ),
  );
}

// ═══════════════════════════════════════════════════════════════
// ADMIN LOGS
// ═══════════════════════════════════════════════════════════════
class AdminLogsScreen extends ConsumerWidget {
  const AdminLogsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
    appBar: appBar('Historial global', actions: [
      IconButton(icon: const Icon(Icons.refresh_rounded),
          onPressed: () => ref.invalidate(_logsProvider)),
    ]),
    body: ref.watch(_logsProvider).when(
      loading: () => const Center(child: CircularProgressIndicator(color: AppColors.brand1)),
      error: (e, _) => EmptyState(icon: Icons.error_outline_rounded, title: 'Error', subtitle: e.toString()),
      data: (logs) {
        if (logs.isEmpty) return const EmptyState(icon: Icons.receipt_long_rounded, title: 'Sin registros');
        return ListView.separated(
          padding: const EdgeInsets.all(Sp.lg),
          itemCount: logs.length,
          separatorBuilder: (_, __) => const SizedBox(height: 6),
          itemBuilder: (_, i) {
            final l = logs[i];
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: Sp.md, vertical: 10),
              decoration: BoxDecoration(color: AppColors.surface,
                  borderRadius: BorderRadius.circular(Rx.md),
                  border: Border.all(color: AppColors.border)),
              child: Row(children: [
                Container(width: 8, height: 8,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                        color: l.isSuccess ? AppColors.success : AppColors.error)),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(l.userName ?? l.userEmail ?? '—',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500,
                          color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                  Text(l.locationLabel,
                      style: const TextStyle(fontSize: 11, color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(DateFormat('HH:mm').format(l.createdAt.toLocal()),
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                  Text(DateFormat('d MMM').format(l.createdAt.toLocal()),
                      style: const TextStyle(fontSize: 11, color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
                ]),
              ]),
            );
          },
        );
      },
    ),
  );
}
