// lib/screens/auth/login_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../services/supabase_service.dart';
import '../../utils/constants.dart';
import '../../widgets/widgets.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _pass  = TextEditingController();
  bool _loading = false, _obscure = true;
  String? _error;

  @override void dispose() { _email.dispose(); _pass.dispose(); super.dispose(); }

  Future<void> _login() async {
    if (!_form.currentState!.validate()) return;
    setState(() { _loading = true; _error = null; });
    try {
      await ref.read(supabaseServiceProvider).signIn(_email.text.trim(), _pass.text);
      if (mounted) context.go('/home');
    } catch (e) {
      setState(() {
        _error = e.toString().contains('Invalid') ? 'Email o contraseña incorrectos'
            : e.toString().contains('confirmed') ? 'Confirma tu email antes de entrar'
            : 'Error al iniciar sesión';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: Sp.lg, vertical: Sp.lg),
        child: Form(key: _form, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 32),

          // Logo
          Center(child: Column(children: [
            Container(width: 72, height: 72,
                decoration: BoxDecoration(
                  gradient: AppColors.brandGradient,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: AppColors.brandGlow1, blurRadius: 24, spreadRadius: 4)],
                ),
                child: const Icon(Icons.local_parking_rounded, color: Colors.white, size: 36)),
            const SizedBox(height: Sp.md),
            const Text('Appertura', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w700,
                color: AppColors.textPrimary, letterSpacing: -1, fontFamily: 'SpaceGrotesk')),
            const SizedBox(height: 4),
            const Text('Acceso inteligente al parking',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 14, fontFamily: 'SpaceGrotesk')),
          ])),

          const SizedBox(height: 40),

          const Text('Iniciar sesión', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
              color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
          const SizedBox(height: Sp.xs),
          const Text('Entra con tu cuenta', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'SpaceGrotesk')),
          const SizedBox(height: Sp.xl),

          AppField(label: 'Email', controller: _email, prefixIcon: Icons.email_outlined,
              keyboardType: TextInputType.emailAddress,
              validator: (v) => (v?.isEmpty ?? true) ? 'Campo obligatorio'
                  : !v!.contains('@') ? 'Email no válido' : null),
          const SizedBox(height: Sp.md),

          AppField(label: 'Contraseña', controller: _pass, obscure: _obscure,
              prefixIcon: Icons.lock_outline, textInputAction: TextInputAction.done,
              onToggleObscure: () => setState(() => _obscure = !_obscure),
              onFieldSubmitted: (_) => _login(),
              validator: (v) => (v?.length ?? 0) < 6 ? 'Mínimo 6 caracteres' : null),

          Align(alignment: Alignment.centerRight,
              child: TextButton(onPressed: () => context.push('/forgot'),
                  child: const Text('¿Olvidaste tu contraseña?',
                      style: TextStyle(color: AppColors.brand1, fontSize: 13, fontFamily: 'SpaceGrotesk')))),

          if (_error != null) ...[const SizedBox(height: Sp.sm), ErrorBanner(message: _error!)],
          const SizedBox(height: Sp.lg),

          GradientButton(label: 'Entrar', onPressed: _loading ? null : _login, loading: _loading),
          const SizedBox(height: Sp.xl),

          Center(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('¿Sin cuenta? ', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'SpaceGrotesk')),
            TextButton(onPressed: () => context.push('/register'),
                child: const Text('Regístrate', style: TextStyle(color: AppColors.brand1,
                    fontWeight: FontWeight.w600, fontFamily: 'SpaceGrotesk'))),
          ])),
        ])),
      ),
    ),
  );
}
