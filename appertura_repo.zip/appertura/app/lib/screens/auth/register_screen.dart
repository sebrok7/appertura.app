// lib/screens/auth/register_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../services/supabase_service.dart';
import '../../utils/constants.dart';
import '../../widgets/widgets.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});
  @override ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pass  = TextEditingController();
  bool _loading = false, _obscure = true, _done = false;
  String? _error;

  @override void dispose() { _name.dispose(); _email.dispose(); _pass.dispose(); super.dispose(); }

  Future<void> _register() async {
    if (!_form.currentState!.validate()) return;
    setState(() { _loading = true; _error = null; });
    try {
      await ref.read(supabaseServiceProvider).signUp(
          _email.text.trim(), _pass.text, _name.text.trim());
      if (mounted) setState(() { _loading = false; _done = true; });
    } catch (e) {
      setState(() {
        _error = e.toString().contains('registered') ? 'Este email ya está registrado' : 'Error al registrarse';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: appBar('Crear cuenta'),
    body: SafeArea(
      child: _done
          ? Center(child: Padding(
              padding: const EdgeInsets.all(Sp.xl),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.mark_email_unread_rounded, size: 64, color: AppColors.brand1),
                const SizedBox(height: Sp.lg),
                const Text('¡Cuenta creada!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.sm),
                const Text('Confirma tu email para activar tu cuenta.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textSecondary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.xl),
                GradientButton(label: 'Ir al login', onPressed: () => context.go('/login')),
              ]),
            ))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(Sp.lg),
              child: Form(key: _form, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Bienvenido', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.xs),
                const Text('Crea tu cuenta Appertura',
                    style: TextStyle(color: AppColors.textSecondary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.xl),

                AppField(label: 'Nombre completo', controller: _name,
                    prefixIcon: Icons.person_outline,
                    validator: (v) => (v?.isEmpty ?? true) ? 'Campo obligatorio' : null),
                const SizedBox(height: Sp.md),
                AppField(label: 'Email', controller: _email,
                    prefixIcon: Icons.email_outlined, keyboardType: TextInputType.emailAddress,
                    validator: (v) => (v?.isEmpty ?? true) ? 'Campo obligatorio'
                        : !v!.contains('@') ? 'Email no válido' : null),
                const SizedBox(height: Sp.md),
                AppField(label: 'Contraseña', controller: _pass, obscure: _obscure,
                    prefixIcon: Icons.lock_outline, textInputAction: TextInputAction.done,
                    onToggleObscure: () => setState(() => _obscure = !_obscure),
                    onFieldSubmitted: (_) => _register(),
                    validator: (v) => (v?.length ?? 0) < 8 ? 'Mínimo 8 caracteres' : null),

                if (_error != null) ...[const SizedBox(height: Sp.md), ErrorBanner(message: _error!)],
                const SizedBox(height: Sp.lg),

                GradientButton(label: 'Registrarse', onPressed: _loading ? null : _register, loading: _loading),
                const SizedBox(height: Sp.md),
                Center(child: TextButton(
                    onPressed: () => context.go('/login'),
                    child: const Text('¿Ya tienes cuenta? Inicia sesión',
                        style: TextStyle(color: AppColors.brand1, fontFamily: 'SpaceGrotesk')))),
              ])),
            ),
    ),
  );
}

// ────────────────────────────────────────────────────────────
class ForgotPasswordScreen extends ConsumerStatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override ConsumerState<ForgotPasswordScreen> createState() => _ForgotState();
}

class _ForgotState extends ConsumerState<ForgotPasswordScreen> {
  final _email = TextEditingController();
  bool _loading = false, _sent = false;

  @override void dispose() { _email.dispose(); super.dispose(); }

  Future<void> _send() async {
    if (_email.text.isEmpty) return;
    setState(() => _loading = true);
    try {
      await ref.read(supabaseServiceProvider).resetPassword(_email.text.trim());
      if (mounted) setState(() { _loading = false; _sent = true; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: appBar('Recuperar contraseña'),
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(Sp.lg),
        child: _sent
            ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.email_rounded, size: 64, color: AppColors.brand1),
                const SizedBox(height: Sp.lg),
                const Text('Email enviado', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.sm),
                const Text('Revisa tu bandeja de entrada.',
                    style: TextStyle(color: AppColors.textSecondary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.xl),
                GradientButton(label: 'Volver al login', onPressed: () => context.go('/login')),
              ]))
            : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Recuperar acceso', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.xs),
                const Text('Te enviaremos un enlace para restablecer tu contraseña.',
                    style: TextStyle(color: AppColors.textSecondary, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: Sp.xl),
                AppField(label: 'Email', controller: _email,
                    prefixIcon: Icons.email_outlined, keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.done, onFieldSubmitted: (_) => _send()),
                const SizedBox(height: Sp.lg),
                GradientButton(label: 'Enviar enlace', onPressed: _loading ? null : _send, loading: _loading),
              ]),
      ),
    ),
  );
}
