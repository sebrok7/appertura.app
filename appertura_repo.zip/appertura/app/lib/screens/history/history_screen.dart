// lib/screens/history/history_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../models/models.dart';
import '../../services/supabase_service.dart';
import '../../utils/constants.dart';
import '../../widgets/widgets.dart';

// ─────────────────────────────────────────────────────────────
// HISTORY
// ─────────────────────────────────────────────────────────────
class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final svc = ref.read(supabaseServiceProvider);
    if (svc.currentUser == null) {
      return const Scaffold(body: EmptyState(icon: Icons.history_rounded, title: 'Inicia sesión primero'));
    }
    return Scaffold(
      appBar: appBar('Mis accesos'),
      body: FutureBuilder<List<AccessLog>>(
        future: svc.getMyHistory(limit: 100),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppColors.brand1));
          }
          final logs = snap.data ?? [];
          if (logs.isEmpty) {
            return const EmptyState(
              icon: Icons.history_rounded,
              title: 'Sin accesos registrados',
              subtitle: 'Aquí aparecerán tus aperturas de puerta.',
            );
          }

          final Map<String, List<AccessLog>> grouped = {};
          for (final l in logs) {
            final key = DateFormat('d MMMM yyyy', 'es').format(l.createdAt.toLocal());
            grouped.putIfAbsent(key, () => []).add(l);
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: Sp.lg, vertical: Sp.sm),
            itemCount: grouped.length,
            itemBuilder: (_, gi) {
              final date = grouped.keys.elementAt(gi);
              final items = grouped[date]!;
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SectionLabel(text: date),
                AppCard(
                  padding: EdgeInsets.zero,
                  child: Column(children: List.generate(items.length, (i) {
                    final log = items[i];
                    return Column(children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: Sp.md, vertical: 12),
                        child: Row(children: [
                          Container(
                            width: 38, height: 38,
                            decoration: BoxDecoration(
                              color: log.isSuccess ? AppColors.successGlow : AppColors.errorGlow,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              log.isSuccess ? Icons.check_rounded : Icons.close_rounded,
                              color: log.isSuccess ? AppColors.success : AppColors.error,
                              size: 18),
                          ),
                          const SizedBox(width: Sp.md),
                          Expanded(child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(log.resultLabel,
                                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500,
                                      fontFamily: 'SpaceGrotesk',
                                      color: log.isSuccess ? AppColors.success : AppColors.error)),
                              if (log.locationLabel.isNotEmpty)
                                Text(log.locationLabel,
                                    style: const TextStyle(fontSize: 12,
                                        color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
                            ],
                          )),
                          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(DateFormat('HH:mm').format(log.createdAt.toLocal()),
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                            if (log.bleRssi != null)
                              Text('${log.bleRssi} dBm',
                                  style: const TextStyle(fontSize: 11,
                                      color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
                          ]),
                        ]),
                      ),
                      if (i < items.length - 1)
                        const Divider(height: 1, indent: 16, endIndent: 16),
                    ]);
                  })),
                ),
                const SizedBox(height: Sp.md),
              ]);
            },
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// PROFILE
// ─────────────────────────────────────────────────────────────
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(currentProfileProvider);
    return Scaffold(
      appBar: appBar('Perfil'),
      body: profile.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.brand1)),
        error: (_, __) => const EmptyState(icon: Icons.error_outline_rounded, title: 'Error al cargar'),
        data: (p) => p == null
            ? const EmptyState(icon: Icons.person_off_rounded, title: 'Sin perfil')
            : ListView(padding: const EdgeInsets.all(Sp.lg), children: [

                Center(child: Column(children: [
                  AppAvatar(initials: p.initials, size: 80, isAdmin: p.isAdmin),
                  const SizedBox(height: Sp.md),
                  Text(p.displayName, style: const TextStyle(fontSize: 20,
                      fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
                  const SizedBox(height: 4),
                  Text(p.email, style: const TextStyle(color: AppColors.textSecondary,
                      fontSize: 14, fontFamily: 'SpaceGrotesk')),
                  const SizedBox(height: Sp.sm),
                  StatusChip(
                    label: p.isAdmin ? 'Administrador' : 'Residente',
                    color: p.isAdmin ? AppColors.brand1 : AppColors.success,
                  ),
                ])),

                const SizedBox(height: Sp.xl),
                const Divider(color: AppColors.border),
                const SizedBox(height: Sp.md),

                _MenuItem(Icons.history_rounded, 'Historial de accesos', () => context.go('/history')),
                _MenuItem(Icons.notifications_outlined, 'Notificaciones', () {}),
                _MenuItem(Icons.lock_outline, 'Cambiar contraseña', () {}),

                if (p.isAdmin) ...[
                  const SizedBox(height: Sp.sm),
                  const Divider(color: AppColors.border),
                  const SizedBox(height: Sp.sm),
                  _MenuItem(Icons.admin_panel_settings_rounded, 'Panel de administración',
                      () => context.push('/admin'), color: AppColors.brand1),
                ],

                const SizedBox(height: Sp.xl),

                OutlinedButton.icon(
                  onPressed: () async {
                    await ref.read(supabaseServiceProvider).signOut();
                    if (context.mounted) context.go('/login');
                  },
                  icon: const Icon(Icons.logout_rounded, color: AppColors.error),
                  label: const Text('Cerrar sesión',
                      style: TextStyle(color: AppColors.error, fontFamily: 'SpaceGrotesk')),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.error),
                    minimumSize: const Size(double.infinity, 52),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Rx.md)),
                  ),
                ),
              ]),
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;
  const _MenuItem(this.icon, this.label, this.onTap, {this.color});

  @override
  Widget build(BuildContext context) => ListTile(
    onTap: onTap,
    contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 2),
    leading: Icon(icon, color: color ?? AppColors.textSecondary, size: 22),
    title: Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500,
        color: color ?? AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),
    trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
  );
}
