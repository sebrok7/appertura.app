// lib/screens/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../models/models.dart';
import '../../services/supabase_service.dart';
import '../../services/door_service.dart';
import '../../utils/constants.dart';
import '../../widgets/widgets.dart';

final _selectedPermIdx = StateProvider<int>((_) => 0);

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final permsAsync = ref.watch(userPermissionsProvider);
    final profile    = ref.watch(currentProfileProvider);
    final door       = ref.watch(doorServiceProvider);

    return Scaffold(
      appBar: appBar('', showLogo: true, actions: [
        profile.when(
          data: (p) => p != null
              ? GestureDetector(
                  onTap: () => context.push('/profile'),
                  child: Padding(
                    padding: const EdgeInsets.only(right: Sp.md),
                    child: AppAvatar(initials: p.initials, size: 34, isAdmin: p.isAdmin),
                  ))
              : const SizedBox.shrink(),
          loading: () => const SizedBox.shrink(),
          error: (_, __) => const SizedBox.shrink(),
        ),
      ]),
      body: permsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.brand1)),
        error: (e, _) => EmptyState(icon: Icons.wifi_off_rounded, title: 'Sin conexión', subtitle: e.toString()),
        data: (perms) {
          if (perms.isEmpty) {
            return EmptyState(
              icon: Icons.no_meeting_room_rounded,
              title: 'Sin acceso asignado',
              subtitle: 'Contacta con el administrador de tu parking para que te asigne una plaza.',
            );
          }
          return _HomeBody(perms: perms);
        },
      ),
    );
  }
}

class _HomeBody extends ConsumerWidget {
  final List<DevicePermission> perms;
  const _HomeBody({required this.perms});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final idx    = ref.watch(_selectedPermIdx);
    final door   = ref.watch(doorServiceProvider);
    final profile = ref.watch(currentProfileProvider);
    final perm   = perms[idx.clamp(0, perms.length - 1)];

    return RefreshIndicator(
      color: AppColors.brand1,
      backgroundColor: AppColors.surface,
      onRefresh: () => ref.refresh(userPermissionsProvider.future),
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: Sp.lg),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: Sp.md),

          // Greeting
          profile.when(
            data: (p) {
              final h = DateTime.now().hour;
              final greeting = h < 13 ? 'Buenos días' : h < 20 ? 'Buenas tardes' : 'Buenas noches';
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(greeting, style: const TextStyle(color: AppColors.textSecondary,
                    fontSize: 13, fontFamily: 'SpaceGrotesk')),
                const SizedBox(height: 2),
                Text(p?.displayName.split(' ').first ?? '',
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary, letterSpacing: -0.5, fontFamily: 'SpaceGrotesk')),
              ]);
            },
            loading: () => const SizedBox(height: 54),
            error: (_, __) => const SizedBox.shrink(),
          ),

          const SizedBox(height: Sp.lg),

          // Plaza selector
          if (perms.length > 1) ...[
            const SectionLabel(text: 'Mis plazas'),
            const SizedBox(height: Sp.sm),
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: perms.length,
                separatorBuilder: (_, __) => const SizedBox(width: Sp.sm),
                itemBuilder: (_, i) {
                  final selected = i == idx;
                  return GestureDetector(
                    onTap: () {
                      ref.read(_selectedPermIdx.notifier).state = i;
                      ref.read(doorServiceProvider.notifier).reset();
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: selected ? AppColors.brand1.withOpacity(0.12) : AppColors.surface2,
                        borderRadius: BorderRadius.circular(Rx.md),
                        border: Border.all(
                          color: selected ? AppColors.brand1 : AppColors.border,
                          width: selected ? 1.5 : 1,
                        ),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.local_parking_rounded, size: 14,
                            color: selected ? AppColors.brand1 : AppColors.textMuted),
                        const SizedBox(width: 5),
                        Text(perms[i].device?.displayName ?? 'Plaza ${i+1}',
                            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500,
                                fontFamily: 'SpaceGrotesk',
                                color: selected ? AppColors.brand1 : AppColors.textSecondary)),
                      ]),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: Sp.lg),
          ],

          // ── DOOR CARD ─────────────────────────────────────
          _DoorCard(perm: perm, door: door),

          const SizedBox(height: Sp.md),

          // Last access
          _LastAccessCard(perm: perm),

          const SizedBox(height: Sp.md),

          // Device info
          AppCard(
            child: Row(children: [
              IconBox(icon: Icons.bluetooth_rounded, color: AppColors.brand1),
              const SizedBox(width: Sp.md),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const SectionLabel(text: 'Dispositivo BLE'),
                Text(perm.device?.effectiveBleName ?? '—',
                    style: const TextStyle(fontSize: 14, color: AppColors.textPrimary,
                        fontWeight: FontWeight.w500, fontFamily: 'SpaceGrotesk')),
              ])),
              StatusChip(label: perm.typeLabel,
                  color: perm.permissionType == 'permanent' ? AppColors.success : AppColors.brand1),
            ]),
          ),

          const SizedBox(height: Sp.xxl),
        ]),
      ),
    );
  }
}

class _DoorCard extends ConsumerStatefulWidget {
  final DevicePermission perm;
  final DoorState        door;
  const _DoorCard({required this.perm, required this.door});
  @override ConsumerState<_DoorCard> createState() => _DoorCardState();
}

class _DoorCardState extends ConsumerState<_DoorCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;
  late final Animation<double>    _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
    _pulseAnim = Tween<double>(begin: 1, end: 1.1).animate(
      CurvedAnimation(parent: _pulse, curve: Curves.easeInOut));
  }

  @override
  void didUpdateWidget(_DoorCard old) {
    super.didUpdateWidget(old);
    if (widget.door.isLoading) {
      _pulse.repeat(reverse: true);
    } else {
      _pulse.stop(); _pulse.reset();
    }
  }

  @override void dispose() { _pulse.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final d = widget.door;
    Color borderColor = AppColors.border;
    List<BoxShadow> shadows = [];
    if (d.isSuccess) {
      borderColor = AppColors.success;
      shadows = [BoxShadow(color: AppColors.successGlow, blurRadius: 32, spreadRadius: 8)];
    } else if (d.isError) {
      borderColor = AppColors.error;
      shadows = [BoxShadow(color: AppColors.errorGlow, blurRadius: 24, spreadRadius: 4)];
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 400),
      width: double.infinity,
      padding: const EdgeInsets.all(Sp.lg),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(Rx.xxl),
        border: Border.all(color: borderColor, width: 1.5),
        boxShadow: shadows,
      ),
      child: Column(children: [
        // Parking label
        if (widget.perm.device?.parkingName != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.location_on_outlined, size: 13, color: AppColors.textMuted),
              const SizedBox(width: 3),
              Text(widget.perm.device!.parkingName!,
                  style: const TextStyle(fontSize: 12, color: AppColors.textMuted, fontFamily: 'SpaceGrotesk')),
            ]),
          ),

        Text(widget.perm.device?.displayName ?? 'Mi Plaza',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600,
                color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk')),

        const SizedBox(height: Sp.xl),

        // ── BIG OPEN BUTTON ───────────────────────────────
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Transform.scale(
            scale: d.isLoading ? _pulseAnim.value : 1.0,
            child: GestureDetector(
              onTap: (d.isLoading || d.isSuccess) ? null
                  : () => ref.read(doorServiceProvider.notifier).open(widget.perm),
              child: Container(
                width: 144, height: 144,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: d.isSuccess
                      ? const LinearGradient(colors: [AppColors.success, Color(0xFF16A34A)])
                      : d.isError
                          ? const LinearGradient(colors: [AppColors.error, Color(0xFFDC2626)])
                          : d.isLoading
                              ? LinearGradient(colors: [AppColors.brand1.withOpacity(0.5), AppColors.brand2.withOpacity(0.5)])
                              : AppColors.brandGradientDiag,
                  boxShadow: [
                    BoxShadow(
                      color: d.isSuccess ? AppColors.successGlow
                          : d.isError ? AppColors.errorGlow
                          : AppColors.brandGlow1,
                      blurRadius: 40, spreadRadius: 10),
                    BoxShadow(
                      color: d.isSuccess ? AppColors.successGlow.withOpacity(0.3)
                          : d.isError ? AppColors.errorGlow.withOpacity(0.3)
                          : AppColors.brandGlow2.withOpacity(0.3),
                      blurRadius: 80, spreadRadius: 20),
                  ],
                ),
                child: d.isLoading
                    ? const Center(child: SizedBox(width: 36, height: 36,
                        child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)))
                    : Icon(
                        d.isSuccess ? Icons.check_rounded
                            : d.isError ? Icons.close_rounded
                            : Icons.lock_open_rounded,
                        color: Colors.white, size: 52),
              ),
            ),
          ),
        ),

        const SizedBox(height: Sp.lg),

        // Status badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: Sp.md, vertical: 7),
          decoration: BoxDecoration(
            color: d.isSuccess ? AppColors.successGlow
                : d.isError ? AppColors.errorGlow
                : d.isLoading ? AppColors.brand1.withOpacity(0.1)
                : AppColors.surface2,
            borderRadius: BorderRadius.circular(Rx.round),
            border: Border.all(
              color: d.isSuccess ? AppColors.success.withOpacity(0.4)
                  : d.isError ? AppColors.error.withOpacity(0.4)
                  : d.isLoading ? AppColors.brand1.withOpacity(0.3)
                  : AppColors.border,
            ),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 7, height: 7, decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: d.isSuccess ? AppColors.success
                  : d.isError ? AppColors.error
                  : d.isLoading ? AppColors.brand1
                  : AppColors.textMuted,
            )),
            const SizedBox(width: 7),
            Text(d.label, style: TextStyle(
                fontSize: 13, fontWeight: FontWeight.w500, fontFamily: 'SpaceGrotesk',
                color: d.isSuccess ? AppColors.success
                    : d.isError ? AppColors.error
                    : d.isLoading ? AppColors.brand1
                    : AppColors.textMuted)),
          ]),
        ),

        if (d.isError || d.isSuccess) ...[
          const SizedBox(height: Sp.md),
          TextButton(
            onPressed: () => ref.read(doorServiceProvider.notifier).reset(),
            child: Text(d.isSuccess ? 'Abrir de nuevo' : 'Reintentar',
                style: TextStyle(
                  color: d.isSuccess ? AppColors.success : AppColors.brand1,
                  fontFamily: 'SpaceGrotesk', fontWeight: FontWeight.w500)),
          ),
        ],
      ]),
    );
  }
}

class _LastAccessCard extends ConsumerWidget {
  final DevicePermission perm;
  const _LastAccessCard({required this.perm});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FutureBuilder<List<AccessLog>>(
      future: ref.read(supabaseServiceProvider).getMyHistory(limit: 1),
      builder: (_, snap) {
        final log = snap.data?.firstOrNull;
        return AppCard(
          child: Row(children: [
            IconBox(icon: Icons.history_rounded, color: AppColors.textMuted),
            const SizedBox(width: Sp.md),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SectionLabel(text: 'Último acceso'),
              Text(
                log != null
                    ? DateFormat("d MMM · HH:mm", 'es').format(log.createdAt.toLocal())
                    : 'Sin accesos registrados',
                style: const TextStyle(fontSize: 14, color: AppColors.textPrimary,
                    fontWeight: FontWeight.w500, fontFamily: 'SpaceGrotesk')),
            ])),
            if (log != null)
              Icon(log.isSuccess ? Icons.check_circle_rounded : Icons.cancel_rounded,
                  color: log.isSuccess ? AppColors.success : AppColors.error, size: 20),
          ]),
        );
      },
    );
  }
}
