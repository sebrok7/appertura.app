// lib/services/ble_service.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../utils/constants.dart';

final bleServiceProvider = Provider<BleService>((_) => BleService());

class BleDeviceInfo {
  final ScanResult result;
  final String hardwareId;
  final int rssi;
  const BleDeviceInfo({required this.result, required this.hardwareId, required this.rssi});
  BluetoothDevice get device => result.device;
  String get name => result.device.localName;
  String get signalLabel {
    if (rssi > -60) return 'Excelente';
    if (rssi > -70) return 'Buena';
    if (rssi > -80) return 'Regular';
    return 'Débil';
  }
}

class BleCommandResult {
  final bool ok;
  final bool denied;
  final bool busy;
  final String? errorCode;
  const BleCommandResult._({required this.ok, required this.denied, required this.busy, this.errorCode});
  factory BleCommandResult.success()     => const BleCommandResult._(ok: true,  denied: false, busy: false);
  factory BleCommandResult.denied()      => const BleCommandResult._(ok: false, denied: true,  busy: false);
  factory BleCommandResult.busy()        => const BleCommandResult._(ok: false, denied: false, busy: true);
  factory BleCommandResult.error(String c) => BleCommandResult._(ok: false, denied: false, busy: false, errorCode: c);
}

class BleService {
  BluetoothDevice?         _device;
  BluetoothCharacteristic? _cmdChar;
  BluetoothCharacteristic? _statusChar;
  StreamSubscription?      _connSub;

  Future<bool> isBleOn() async {
    if (!await FlutterBluePlus.isAvailable) return false;
    return await FlutterBluePlus.adapterState.first == BluetoothAdapterState.on;
  }

  Stream<List<BleDeviceInfo>> scan({Duration timeout = const Duration(seconds: 10)}) {
    final map = <String, BleDeviceInfo>{};
    final ctrl = StreamController<List<BleDeviceInfo>>();
    FlutterBluePlus.startScan(timeout: timeout);
    final sub = FlutterBluePlus.scanResults.listen((results) {
      bool changed = false;
      for (final r in results) {
        final name = r.device.localName;
        if (name.startsWith(AppConfig.bleDevicePrefix)) {
          final hwId = name.substring(AppConfig.bleDevicePrefix.length);
          map[r.device.remoteId.str] = BleDeviceInfo(result: r, hardwareId: hwId, rssi: r.rssi);
          changed = true;
        }
      }
      if (changed) {
        final sorted = map.values.toList()..sort((a, b) => b.rssi.compareTo(a.rssi));
        ctrl.add(sorted);
      }
    });
    FlutterBluePlus.isScanning.listen((scanning) {
      if (!scanning) { ctrl.close(); sub.cancel(); }
    });
    return ctrl.stream;
  }

  Future<void> connect(BluetoothDevice dev) async {
    await disconnect();
    await dev.connect(timeout: const Duration(milliseconds: AppConfig.bleConnectTimeoutMs), autoConnect: false);
    _device = dev;
    final services = await dev.discoverServices();
    _findChars(services);
    _connSub = dev.connectionState.listen((s) {
      if (s == BluetoothConnectionState.disconnected) { _cmdChar = null; _statusChar = null; _device = null; }
    });
  }

  void _findChars(List<BluetoothService> services) {
    for (final svc in services) {
      if (svc.uuid.toString().toLowerCase() == AppConfig.bleServiceUuid.toLowerCase()) {
        for (final c in svc.characteristics) {
          final u = c.uuid.toString().toLowerCase();
          if (u == AppConfig.bleCmdCharUuid.toLowerCase())    _cmdChar    = c;
          if (u == AppConfig.bleStatusCharUuid.toLowerCase()) _statusChar = c;
        }
      }
    }
    if (_cmdChar == null) throw Exception('BLE_SERVICE_NOT_FOUND');
  }

  Future<BleCommandResult> sendOpen({
    required String deviceHwId, required String token, required int relayMs,
  }) async {
    if (_cmdChar == null) throw Exception('NOT_CONNECTED');
    final payload = _buildPayload(deviceHwId, token, relayMs);
    await _cmdChar!.write(payload, withoutResponse: false);
    final resp = await _readResponse();
    return _parse(resp);
  }

  List<int> _buildPayload(String deviceId, String token, int pulseMs) {
    final p = <int>[];
    p.add(AppConfig.cmdOpen);
    p.add((pulseMs >> 8) & 0xFF);
    p.add(pulseMs & 0xFF);
    final tokBytes = utf8.encode(token.length > 64 ? token.substring(0, 64) : token);
    p.add(tokBytes.length);
    p.addAll(tokBytes);
    final idBytes = utf8.encode(deviceId.length > 16 ? deviceId.substring(0, 16) : deviceId);
    p.add(idBytes.length);
    p.addAll(idBytes);
    return p;
  }

  Future<List<int>> _readResponse() async {
    if (_statusChar != null) {
      try {
        await _statusChar!.setNotifyValue(true);
        final c = Completer<List<int>>();
        final sub = _statusChar!.lastValueStream.listen((v) {
          if (v.isNotEmpty && !c.isCompleted) c.complete(v);
        });
        final r = await c.future.timeout(
          const Duration(milliseconds: AppConfig.bleCommandTimeoutMs));
        sub.cancel();
        return r;
      } catch (_) {}
    }
    return await _cmdChar!.read();
  }

  BleCommandResult _parse(List<int> b) {
    if (b.isEmpty) return BleCommandResult.error('EMPTY');
    return switch (b[0]) {
      AppConfig.respOk           => BleCommandResult.success(),
      AppConfig.respDenied       => BleCommandResult.denied(),
      AppConfig.respTokenExpired => BleCommandResult.error('TOKEN_EXPIRED'),
      AppConfig.respBusy         => BleCommandResult.busy(),
      _                          => BleCommandResult.error('UNKNOWN_0x${b[0].toRadixString(16)}'),
    };
  }

  Future<void> stopScan() => FlutterBluePlus.stopScan();

  Future<void> disconnect() async {
    _connSub?.cancel();
    _cmdChar = null; _statusChar = null;
    try { await _device?.disconnect(); } catch (_) {}
    _device = null;
  }
}
