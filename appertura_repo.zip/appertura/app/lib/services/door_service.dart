// lib/services/door_service.dart
import 'dart:async';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../utils/constants.dart';
import 'ble_service.dart';
import 'supabase_service.dart';

// ── State ────────────────────────────────────────────────────
class DoorState {
  final OpenDoorState  step;
  final OpenDoorError? error;
  final String?        message;
  final int?           rssi;

  const DoorState({required this.step, this.error, this.message, this.rssi});
  const DoorState.idle()    : this(step: OpenDoorState.idle);
  const DoorState.success(int r) : this(step: OpenDoorState.success, rssi: r);

  bool get isIdle    => step == OpenDoorState.idle;
  bool get isLoading => !isIdle && step != OpenDoorState.success && step != OpenDoorState.error;
  bool get isSuccess => step == OpenDoorState.success;
  bool get isError   => step == OpenDoorState.error;

  String get label {
    if (message != null) return message!;
    return switch (step) {
      OpenDoorState.idle             => 'Listo para abrir',
      OpenDoorState.checkingPermission => 'Verificando permisos...',
      OpenDoorState.scanningBle      => 'Buscando dispositivo...',
      OpenDoorState.connecting       => 'Conectando...',
      OpenDoorState.authenticating   => 'Autenticando...',
      OpenDoorState.activatingRelay  => 'Abriendo puerta...',
      OpenDoorState.success          => '¡Puerta abierta!',
      OpenDoorState.error            => _errLabel,
    };
  }

  String get _errLabel => switch (error) {
    OpenDoorError.noPermission    => 'Sin permisos de acceso',
    OpenDoorError.deviceNotFound  => 'Dispositivo fuera de alcance',
    OpenDoorError.connectionFailed => 'Error de conexión BLE',
    OpenDoorError.authFailed      => 'Autenticación fallida',
    OpenDoorError.relayError      => 'Error al activar el relé',
    OpenDoorError.timeout         => 'Tiempo agotado',
    OpenDoorError.bleDisabled     => 'Activa el Bluetooth',
    _                             => 'Error desconocido',
  };
}

// ── Provider ─────────────────────────────────────────────────
final doorServiceProvider =
    StateNotifierProvider<DoorNotifier, DoorState>((ref) => DoorNotifier(
      ble: ref.read(bleServiceProvider),
      supa: ref.read(supabaseServiceProvider),
    ));

// ── Notifier ─────────────────────────────────────────────────
class DoorNotifier extends StateNotifier<DoorState> {
  final BleService      _ble;
  final SupabaseService _supa;
  Timer? _timeout;

  DoorNotifier({required BleService ble, required SupabaseService supa})
      : _ble = ble, _supa = supa, super(const DoorState.idle());

  void reset() { _timeout?.cancel(); state = const DoorState.idle(); }

  Future<void> open(DevicePermission perm) async {
    if (state.isLoading) return;
    final user = _supa.currentUser;
    if (user == null) { _err(OpenDoorError.noPermission, 'Sin sesión activa'); return; }

    _timeout = Timer(const Duration(seconds: 30), () {
      if (state.isLoading) { _err(OpenDoorError.timeout); _ble.disconnect(); }
    });

    try {
      // 1 — Verificar BLE
      _set(OpenDoorState.checkingPermission, 'Verificando permisos...');
      if (!await _ble.isBleOn()) { _err(OpenDoorError.bleDisabled); return; }

      // 2 — Generar token en backend
      _set(OpenDoorState.checkingPermission, 'Obteniendo credenciales...');
      BleTokenResult token;
      try {
        token = await _supa.generateBleToken(user.id, perm.deviceId);
      } on Exception catch (e) {
        final msg = e.toString();
        if (msg.contains('ACCESS_DENIED') || msg.contains('USER_SUSPENDED')) {
          _err(OpenDoorError.noPermission); return;
        }
        _err(OpenDoorError.authFailed, msg); return;
      }

      if (token.isExpired) { _err(OpenDoorError.authFailed, 'Token expirado'); return; }

      // 3 — Escanear BLE
      _set(OpenDoorState.scanningBle, 'Buscando ${perm.device?.displayName ?? "dispositivo"}...');
      final targetName = perm.device?.effectiveBleName ?? '';

      BleDeviceInfo? found;
      int rssi = -99;

      await for (final devices in _ble.scan(timeout: const Duration(seconds: 10))) {
        found = devices.cast<BleDeviceInfo?>().firstWhere(
          (d) => d!.name == targetName || d.hardwareId == (perm.device?.deviceHwId ?? ''),
          orElse: () => null,
        );
        if (found != null) { rssi = found.rssi; await _ble.stopScan(); break; }
      }

      if (found == null) {
        _err(OpenDoorError.deviceNotFound, 'Acércate más al dispositivo');
        await _log(user.id, perm.deviceId, 'error', null, 'DEVICE_NOT_FOUND', null);
        return;
      }

      // 4 — Conectar
      _set(OpenDoorState.connecting, 'Conectando...');
      try {
        await _ble.connect(found.device);
      } on Exception {
        _err(OpenDoorError.connectionFailed);
        await _log(user.id, perm.deviceId, 'error', rssi, 'CONNECTION_FAILED', null);
        return;
      }

      // 5 — Enviar comando
      _set(OpenDoorState.authenticating, 'Autenticando...');
      await Future.delayed(const Duration(milliseconds: 200));
      _set(OpenDoorState.activatingRelay, 'Abriendo puerta...');

      BleCommandResult cmd;
      try {
        cmd = await _ble.sendOpen(
          deviceHwId: perm.device?.deviceHwId ?? '',
          token: token.token,
          relayMs: token.relayPulseMs,
        );
      } on Exception catch (e) {
        await _ble.disconnect();
        _err(OpenDoorError.relayError, e.toString());
        await _log(user.id, perm.deviceId, 'error', rssi, 'RELAY_ERROR', token.tokenId);
        return;
      } finally {
        await _ble.disconnect();
      }

      _timeout?.cancel();

      if (cmd.ok) {
        state = DoorState.success(rssi);
        await _log(user.id, perm.deviceId, 'success', rssi, null, token.tokenId);
      } else if (cmd.denied) {
        _err(OpenDoorError.authFailed, 'Acceso denegado por el dispositivo');
        await _log(user.id, perm.deviceId, 'denied', rssi, 'DEVICE_DENIED', token.tokenId);
      } else if (cmd.busy) {
        _err(OpenDoorError.relayError, 'Dispositivo ocupado, espera 3 segundos');
        await _log(user.id, perm.deviceId, 'error', rssi, 'DEVICE_BUSY', token.tokenId);
      } else {
        _err(OpenDoorError.relayError, cmd.errorCode);
        await _log(user.id, perm.deviceId, 'error', rssi, cmd.errorCode, token.tokenId);
      }

    } catch (e) {
      _err(OpenDoorError.unknown, e.toString());
    } finally {
      _timeout?.cancel();
    }
  }

  void _set(OpenDoorState s, [String? msg]) {
    state = DoorState(step: s, message: msg);
  }

  void _err(OpenDoorError e, [String? msg]) {
    _timeout?.cancel();
    state = DoorState(step: OpenDoorState.error, error: e, message: msg);
  }

  Future<void> _log(String uid, String did, String res, int? rssi, String? code, String? tokenId) async {
    try {
      await _supa.logAccess(
        userId: uid, deviceId: did, result: res,
        bleRssi: rssi, errorCode: code, tokenId: tokenId,
      );
    } catch (_) {}
  }

  @override
  void dispose() { _timeout?.cancel(); super.dispose(); }
}
