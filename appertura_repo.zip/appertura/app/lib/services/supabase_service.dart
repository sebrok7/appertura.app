// lib/services/supabase_service.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/models.dart';

final supabaseServiceProvider = Provider<SupabaseService>((_) => SupabaseService());

final authStateProvider = StreamProvider<User?>((ref) =>
    Supabase.instance.client.auth.onAuthStateChange.map((e) => e.session?.user));

final currentProfileProvider = FutureProvider<UserProfile?>((ref) async {
  final user = ref.watch(authStateProvider).value;
  if (user == null) return null;
  return ref.read(supabaseServiceProvider).getProfile(user.id);
});

final userPermissionsProvider = FutureProvider<List<DevicePermission>>((ref) async {
  final user = Supabase.instance.client.auth.currentUser;
  if (user == null) return [];
  return ref.read(supabaseServiceProvider).getUserPermissions(user.id);
});

class SupabaseService {
  SupabaseClient get _db => Supabase.instance.client;

  // ── AUTH ─────────────────────────────────────────────────
  User? get currentUser => _db.auth.currentUser;

  Future<AuthResponse> signIn(String email, String password) =>
      _db.auth.signInWithPassword(email: email, password: password);

  Future<AuthResponse> signUp(String email, String password, String fullName) =>
      _db.auth.signUp(email: email, password: password, data: {'full_name': fullName});

  Future<void> signOut() => _db.auth.signOut();

  Future<void> resetPassword(String email) =>
      _db.auth.resetPasswordForEmail(email, redirectTo: 'appertura://reset-password');

  Future<void> updatePassword(String newPass) =>
      _db.auth.updateUser(UserAttributes(password: newPass));

  // ── PROFILE ──────────────────────────────────────────────
  Future<UserProfile?> getProfile(String userId) async {
    final d = await _db.from('profiles').select().eq('id', userId).maybeSingle();
    return d != null ? UserProfile.fromJson(d) : null;
  }

  Future<void> updateProfile(String userId, {String? fullName, String? phone}) async {
    await _db.from('profiles').update({
      if (fullName != null) 'full_name': fullName,
      if (phone != null) 'phone': phone,
    }).eq('id', userId);
  }

  // ── PERMISSIONS (user view) ───────────────────────────────
  Future<List<DevicePermission>> getUserPermissions(String userId) async {
    final data = await _db.from('v_user_devices').select().eq('user_id', userId);
    return (data as List).map((j) => DevicePermission.fromView(j)).toList();
  }

  // ── BLE TOKEN ─────────────────────────────────────────────
  Future<BleTokenResult> generateBleToken(String userId, String deviceId) async {
    final res = await _db.rpc('generate_ble_token', params: {
      'p_user_id': userId, 'p_device_id': deviceId,
    });
    if (res == null || (res as List).isEmpty) throw Exception('TOKEN_GENERATION_FAILED');
    return BleTokenResult.fromJson(res[0]);
  }

  // ── ACCESS LOG ────────────────────────────────────────────
  Future<void> logAccess({
    required String userId, required String deviceId, required String result,
    int? bleRssi, String? errorCode, String? tokenId,
  }) async {
    await _db.rpc('log_access', params: {
      'p_user_id': userId, 'p_device_id': deviceId, 'p_result': result,
      'p_ble_rssi': bleRssi, 'p_error_code': errorCode,
      'p_app_version': '1.0.0',
      if (tokenId != null) 'p_token_id': tokenId,
    });
  }

  // ── HISTORY (user) ────────────────────────────────────────
  Future<List<AccessLog>> getMyHistory({int limit = 100, String? deviceId}) async {
    var q = _db.from('v_access_logs').select()
        .eq('user_id', currentUser!.id)
        .order('created_at', ascending: false)
        .limit(limit);
    final data = await q;
    return (data as List).map((j) => AccessLog.fromJson(j)).toList();
  }

  // ── ADMIN: STATS ──────────────────────────────────────────
  Future<AdminStats> getAdminStats() async {
    final res = await _db.rpc('get_admin_stats');
    return AdminStats.fromJson(res as Map<String, dynamic>);
  }

  // ── ADMIN: USERS ──────────────────────────────────────────
  Future<List<UserProfile>> getAllUsers() async {
    final d = await _db.from('profiles').select().order('created_at', ascending: false);
    return (d as List).map((j) => UserProfile.fromJson(j)).toList();
  }

  Future<void> createUser(String email, String password, String fullName, {String role = 'resident'}) async {
    // Crea el usuario directamente — el trigger auto-crea el profile
    final res = await _db.auth.admin.createUser(AdminUserAttributes(
      email: email, password: password,
      emailConfirm: true,
      userMetadata: {'full_name': fullName},
    ));
    if (res.user != null && role != 'resident') {
      await _db.from('profiles').update({'role': role, 'full_name': fullName}).eq('id', res.user!.id);
    }
  }

  Future<void> updateUser(String userId, {String? fullName, String? phone, String? role}) async {
    await _db.from('profiles').update({
      if (fullName != null) 'full_name': fullName,
      if (phone != null) 'phone': phone,
      if (role != null) 'role': role,
    }).eq('id', userId);
  }

  Future<void> suspendUser(String userId, String reason) async {
    await _db.from('profiles').update({
      'is_active': false,
      'suspended_at': DateTime.now().toIso8601String(),
      'suspended_reason': reason,
    }).eq('id', userId);
  }

  Future<void> reactivateUser(String userId) async {
    await _db.from('profiles').update({
      'is_active': true, 'suspended_at': null, 'suspended_reason': null,
    }).eq('id', userId);
  }

  Future<void> deleteUser(String userId) async {
    await _db.auth.admin.deleteUser(userId);
  }

  // ── ADMIN: DEVICES ────────────────────────────────────────
  Future<List<ParkingDevice>> getAllDevices() async {
    final d = await _db.from('devices').select('''
      *, parking_spaces (number, label, parking_id,
        parkings (name, community_id, communities (name)))
    ''').order('created_at', ascending: false);
    return (d as List).map((j) => ParkingDevice.fromDeviceJson(j)).toList();
  }

  Future<ParkingDevice> createDevice({
    required String deviceId, String? bleName, String? bleMac,
    String? spaceId, int relayPulseMs = 500, String? notes,
  }) async {
    final d = await _db.from('devices').insert({
      'device_id': deviceId,
      'ble_name': bleName ?? 'APARKAO_$deviceId',
      'ble_mac': bleMac, 'space_id': spaceId,
      'relay_pulse_ms': relayPulseMs, 'notes': notes,
    }).select('''*, parking_spaces(number, label, parking_id,
      parkings(name))''').single();
    return ParkingDevice.fromDeviceJson(d);
  }

  Future<void> updateDevice(String deviceId, {
    String? bleName, int? relayPulseMs, String? spaceId, String? notes
  }) async {
    await _db.from('devices').update({
      if (bleName != null) 'ble_name': bleName,
      if (relayPulseMs != null) 'relay_pulse_ms': relayPulseMs,
      if (spaceId != null) 'space_id': spaceId,
      if (notes != null) 'notes': notes,
    }).eq('id', deviceId);
  }

  Future<void> deactivateDevice(String deviceId) async {
    await _db.from('devices').update({'is_active': false}).eq('id', deviceId);
  }

  // ── ADMIN: PERMISSIONS ────────────────────────────────────
  Future<void> grantPermission({
    required String userId, required String deviceId,
    String type = 'permanent', DateTime? validFrom, DateTime? validUntil, int? maxUses,
  }) async {
    await _db.from('user_device_permissions').upsert({
      'user_id': userId, 'device_id': deviceId, 'permission_type': type,
      'valid_from': validFrom?.toIso8601String(),
      'valid_until': validUntil?.toIso8601String(),
      'max_uses': maxUses, 'is_active': true,
      'granted_by': currentUser?.id,
    }, onConflict: 'user_id,device_id');
  }

  Future<void> revokePermission(String userId, String deviceId) async {
    await _db.from('user_device_permissions').update({'is_active': false})
        .eq('user_id', userId).eq('device_id', deviceId);
  }

  Future<List<Map<String, dynamic>>> getDevicePermissions(String deviceId) async {
    final d = await _db.from('user_device_permissions').select('''
      *, profiles (full_name, email)
    ''').eq('device_id', deviceId).eq('is_active', true);
    return (d as List).cast<Map<String, dynamic>>();
  }

  // ── ADMIN: LOGS ───────────────────────────────────────────
  Future<List<AccessLog>> getAllLogs({int limit = 200, DateTime? from}) async {
    var q = _db.from('v_access_logs').select()
        .order('created_at', ascending: false)
        .limit(limit);
    final data = await q;
    return (data as List).map((j) => AccessLog.fromJson(j)).toList();
  }

  // ── ADMIN: PARKINGS & SPACES ──────────────────────────────
  Future<List<Map<String, dynamic>>> getAllParkings() async {
    return (await _db.from('parkings').select('*, communities(name)')
        .eq('is_active', true).order('name'))
        .cast<Map<String, dynamic>>();
  }

  Future<List<Map<String, dynamic>>> getParkingSpaces(String parkingId) async {
    return (await _db.from('parking_spaces').select()
        .eq('parking_id', parkingId).eq('is_active', true).order('number'))
        .cast<Map<String, dynamic>>();
  }

  Future<void> createParking({required String name, String? address, String? city, String? communityId}) async {
    await _db.from('parkings').insert({
      'name': name, 'address': address, 'city': city, 'community_id': communityId,
    });
  }

  Future<void> createParkingSpace({required String parkingId, required String number, String? label}) async {
    await _db.from('parking_spaces').insert({
      'parking_id': parkingId, 'number': number, 'label': label,
    });
  }
}
