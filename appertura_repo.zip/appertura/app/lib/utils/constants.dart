// lib/utils/constants.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ────────────────────────────────────────────────────────────
// CONFIG
// ────────────────────────────────────────────────────────────
class AppConfig {
  // Supabase — inyectadas via --dart-define en build
  static const supabaseUrl     = String.fromEnvironment('SUPABASE_URL',     defaultValue: 'https://YOUR_REF.supabase.co');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: 'YOUR_ANON_KEY');

  // BLE
  static const bleServiceUuid    = '12345678-1234-1234-1234-123456789abc';
  static const bleCmdCharUuid    = '12345678-1234-1234-1234-123456789abd';
  static const bleStatusCharUuid = '12345678-1234-1234-1234-123456789abe';
  static const bleDevicePrefix   = 'APARKAO_';
  static const bleConnectTimeoutMs   = 8000;
  static const bleCommandTimeoutMs   = 5000;
  static const relayPulseDefaultMs   = 500;
  static const tokenValidSeconds     = 30;
  static const bleAntiReboteSeconds  = 3;

  // BLE commands
  static const cmdOpen  = 0x01;
  static const cmdPing  = 0x02;
  static const cmdClose = 0x03;

  // BLE responses
  static const respOk           = 0xA0;
  static const respDenied       = 0xA1;
  static const respError        = 0xA2;
  static const respTokenExpired = 0xA3;
  static const respBusy         = 0xA4;

  static const appVersion = '1.0.0';
  static const deepLinkScheme = 'appertura';
}

// ────────────────────────────────────────────────────────────
// IDENTIDAD VISUAL APARKAO
// ────────────────────────────────────────────────────────────
class AppColors {
  // Brand
  static const brand1 = Color(0xFFF57F56);
  static const brand2 = Color(0xFFFF2562);

  // Gradiente corporativo
  static const brandGradient = LinearGradient(
    colors: [Color(0xFFF57F56), Color(0xFFFF2562)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
  static const brandGradientDiag = LinearGradient(
    colors: [Color(0xFFF57F56), Color(0xFFFF2562)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const brandGradientVert = LinearGradient(
    colors: [Color(0xFFF57F56), Color(0xFFFF2562)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  // Glow
  static const brandGlow1 = Color(0x40F57F56); // rgba(245,127,86,0.25)
  static const brandGlow2 = Color(0x40FF2562); // rgba(255,37,98,0.25)

  // Fondos
  static const bg       = Color(0xFF050816);
  static const surface  = Color(0xFF0E1225);
  static const surface2 = Color(0xFF151B34);
  static const surface3 = Color(0xFF1C2340);

  // Texto
  static const textPrimary   = Color(0xFFFFFFFF);
  static const textSecondary = Color(0xFFA5ACC7);
  static const textMuted     = Color(0xFF4A5180);

  // Bordes
  static const border       = Color(0xFF1E2540);
  static const borderActive = Color(0xFFF57F56);

  // Estados
  static const success      = Color(0xFF22C55E);
  static const successGlow  = Color(0x3322C55E);
  static const error        = Color(0xFFEF4444);
  static const errorGlow    = Color(0x33EF4444);
  static const warning      = Color(0xFFF59E0B);
  static const warningGlow  = Color(0x33F59E0B);
  static const info         = Color(0xFF3B82F6);

  // BLE states usando brand
  static Color get bleScanning  => brand1;
  static Color get bleConnected => brand2;
  static Color get bleIdle      => textMuted;

  // Helpers
  static Color brandWithOpacity(double op) => brand1.withOpacity(op);
}

// ────────────────────────────────────────────────────────────
// THEME
// ────────────────────────────────────────────────────────────
class AppTheme {
  static ThemeData get dark {
    final base = GoogleFonts.spaceGroteskTextTheme();
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.bg,
      colorScheme: const ColorScheme.dark(
        primary:    AppColors.brand1,
        secondary:  AppColors.brand2,
        surface:    AppColors.surface,
        error:      AppColors.error,
        onPrimary:  AppColors.textPrimary,
        onSecondary:AppColors.textPrimary,
        onSurface:  AppColors.textPrimary,
      ),
      textTheme: base.copyWith(
        displayLarge:  base.displayLarge?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 32, fontWeight: FontWeight.w700,
          color: AppColors.textPrimary, letterSpacing: -0.8, height: 1.1),
        displayMedium: base.displayMedium?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 26, fontWeight: FontWeight.w700,
          color: AppColors.textPrimary, letterSpacing: -0.5),
        headlineMedium:base.headlineMedium?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 20, fontWeight: FontWeight.w600,
          color: AppColors.textPrimary),
        titleLarge:    base.titleLarge?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 18, fontWeight: FontWeight.w600,
          color: AppColors.textPrimary),
        titleMedium:   base.titleMedium?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 16, fontWeight: FontWeight.w500,
          color: AppColors.textPrimary),
        bodyLarge:     base.bodyLarge?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 16, fontWeight: FontWeight.w400,
          color: AppColors.textPrimary),
        bodyMedium:    base.bodyMedium?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 14, fontWeight: FontWeight.w400,
          color: AppColors.textSecondary),
        bodySmall:     base.bodySmall?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 12, fontWeight: FontWeight.w400,
          color: AppColors.textMuted),
        labelLarge:    base.labelLarge?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 14, fontWeight: FontWeight.w600,
          color: AppColors.textPrimary, letterSpacing: 0.3),
        labelSmall:    base.labelSmall?.copyWith(
          fontFamily: 'SpaceGrotesk', fontSize: 11, fontWeight: FontWeight.w500,
          color: AppColors.textMuted, letterSpacing: 1.2),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.bg,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: AppColors.textPrimary),
        titleTextStyle: TextStyle(
          fontFamily: 'SpaceGrotesk', fontSize: 17, fontWeight: FontWeight.w600,
          color: AppColors.textPrimary),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surface2,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.brand1, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.error),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.error, width: 1.5),
        ),
        labelStyle: const TextStyle(color: AppColors.textSecondary, fontFamily: 'SpaceGrotesk'),
        hintStyle: const TextStyle(color: AppColors.textMuted, fontFamily: 'SpaceGrotesk'),
        prefixIconColor: AppColors.textSecondary,
        suffixIconColor: AppColors.textSecondary,
        errorStyle: const TextStyle(color: AppColors.error, fontFamily: 'SpaceGrotesk', fontSize: 12),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) return AppColors.surface3;
            return AppColors.brand1;
          }),
          foregroundColor: WidgetStateProperty.all(AppColors.textPrimary),
          minimumSize: WidgetStateProperty.all(const Size(double.infinity, 52)),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          textStyle: WidgetStateProperty.all(const TextStyle(
            fontFamily: 'SpaceGrotesk', fontSize: 15, fontWeight: FontWeight.w600)),
          elevation: WidgetStateProperty.all(0),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.all(AppColors.brand1),
          side: WidgetStateProperty.all(const BorderSide(color: AppColors.brand1, width: 1.5)),
          minimumSize: WidgetStateProperty.all(const Size(double.infinity, 52)),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          textStyle: WidgetStateProperty.all(const TextStyle(
            fontFamily: 'SpaceGrotesk', fontSize: 15, fontWeight: FontWeight.w600)),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.all(AppColors.brand1),
          textStyle: WidgetStateProperty.all(const TextStyle(
            fontFamily: 'SpaceGrotesk', fontSize: 14, fontWeight: FontWeight.w500)),
        ),
      ),
      cardTheme: CardTheme(
        color: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: AppColors.border),
        ),
        elevation: 0,
        margin: EdgeInsets.zero,
      ),
      dividerTheme: const DividerThemeData(color: AppColors.border, thickness: 1),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.surface,
        indicatorColor: AppColors.brand1.withOpacity(0.15),
        labelTextStyle: WidgetStateProperty.all(const TextStyle(
          fontFamily: 'SpaceGrotesk', fontSize: 11, fontWeight: FontWeight.w500)),
        iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
          color: s.contains(WidgetState.selected) ? AppColors.brand1 : AppColors.textMuted,
        )),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.surface2,
        contentTextStyle: const TextStyle(color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk'),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        behavior: SnackBarBehavior.floating,
        elevation: 0,
      ),
    );
  }
}

// ────────────────────────────────────────────────────────────
// SPACING & RADIUS
// ────────────────────────────────────────────────────────────
class Sp {
  static const double xs  = 4;
  static const double sm  = 8;
  static const double md  = 16;
  static const double lg  = 24;
  static const double xl  = 32;
  static const double xxl = 48;
}

class Rx {
  static const double sm    = 8;
  static const double md    = 12;
  static const double lg    = 16;
  static const double xl    = 20;
  static const double xxl   = 24;
  static const double round = 100;
}
