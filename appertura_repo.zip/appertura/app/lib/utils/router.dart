// lib/utils/router.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/history/history_screen.dart';
import '../screens/admin/admin_screen.dart';
import 'constants.dart';

final routerProvider = Provider<GoRouter>((ref) => GoRouter(
  initialLocation: '/login',
  redirect: (ctx, state) {
    final user = Supabase.instance.client.auth.currentUser;
    final loc = state.uri.path;
    final isAuth = ['/login', '/register', '/forgot'].contains(loc);
    if (user == null && !isAuth) return '/login';
    if (user != null && isAuth) return '/home';
    return null;
  },
  routes: [
    GoRoute(path: '/login',    builder: (_, __) => const LoginScreen()),
    GoRoute(path: '/register', builder: (_, __) => const RegisterScreen()),
    GoRoute(path: '/forgot',   builder: (_, __) => const ForgotPasswordScreen()),

    ShellRoute(
      builder: (_, __, child) => _Shell(child: child),
      routes: [
        GoRoute(path: '/home',    builder: (_, __) => const HomeScreen()),
        GoRoute(path: '/history', builder: (_, __) => const HistoryScreen()),
        GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
      ],
    ),

    GoRoute(
      path: '/admin',
      builder: (_, __) => const AdminDashboardScreen(),
      routes: [
        GoRoute(path: 'users',   builder: (_, __) => const AdminUsersScreen()),
        GoRoute(path: 'devices', builder: (_, __) => const AdminDevicesScreen()),
        GoRoute(path: 'logs',    builder: (_, __) => const AdminLogsScreen()),
      ],
    ),
  ],
));

class _Shell extends ConsumerWidget {
  final Widget child;
  const _Shell({required this.child});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loc = GoRouterState.of(context).uri.path;
    final tabs = [
      (path: '/home',    icon: Icons.garage_rounded,  label: 'Acceso'),
      (path: '/history', icon: Icons.history_rounded,  label: 'Historial'),
      (path: '/profile', icon: Icons.person_rounded,   label: 'Perfil'),
    ];
    final idx = tabs.indexWhere((t) => loc.startsWith(t.path));

    return Scaffold(
      body: child,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.border))),
        child: NavigationBar(
          selectedIndex: idx < 0 ? 0 : idx,
          onDestinationSelected: (i) => context.go(tabs[i].path),
          destinations: tabs.map((t) => NavigationDestination(
            icon: Icon(t.icon), label: t.label)).toList(),
        ),
      ),
    );
  }
}
