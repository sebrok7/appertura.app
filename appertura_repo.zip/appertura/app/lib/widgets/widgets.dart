// lib/widgets/widgets.dart
import 'package:flutter/material.dart';
import '../utils/constants.dart';

// ── Gradient button ───────────────────────────────────────────
class GradientButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final double height;
  final IconData? icon;

  const GradientButton({
    super.key, required this.label, this.onPressed,
    this.loading = false, this.height = 52, this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: height,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: onPressed != null ? AppColors.brandGradient
              : const LinearGradient(colors: [Color(0xFF1C2340), Color(0xFF1C2340)]),
          borderRadius: BorderRadius.circular(Rx.md),
          boxShadow: onPressed != null ? [
            BoxShadow(color: AppColors.brandGlow1, blurRadius: 16, offset: const Offset(0, 4)),
          ] : [],
        ),
        child: ElevatedButton(
          onPressed: loading ? null : onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Rx.md)),
          ),
          child: loading
              ? const SizedBox(width: 22, height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  if (icon != null) ...[Icon(icon, size: 18), const SizedBox(width: 8)],
                  Text(label),
                ]),
        ),
      ),
    );
  }
}

// ── App text field ────────────────────────────────────────────
class AppField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final bool obscure;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final String? Function(String?)? validator;
  final VoidCallback? onToggleObscure;
  final IconData? prefixIcon;
  final String? hint;
  final bool autofocus;
  final void Function(String)? onFieldSubmitted;

  const AppField({
    super.key, required this.label, required this.controller,
    this.obscure = false, this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next, this.validator,
    this.onToggleObscure, this.prefixIcon, this.hint,
    this.autofocus = false, this.onFieldSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      textInputAction: textInputAction,
      validator: validator,
      autofocus: autofocus,
      onFieldSubmitted: onFieldSubmitted,
      style: const TextStyle(color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk'),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: prefixIcon != null ? Icon(prefixIcon, size: 20) : null,
        suffixIcon: onToggleObscure != null
            ? IconButton(
                icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 20),
                onPressed: onToggleObscure)
            : null,
      ),
    );
  }
}

// ── Error banner ──────────────────────────────────────────────
class ErrorBanner extends StatelessWidget {
  final String message;
  const ErrorBanner({super.key, required this.message});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: Sp.md, vertical: Sp.sm + 2),
    decoration: BoxDecoration(
      color: AppColors.errorGlow,
      borderRadius: BorderRadius.circular(Rx.md),
      border: Border.all(color: AppColors.error.withOpacity(0.4)),
    ),
    child: Row(children: [
      const Icon(Icons.error_outline_rounded, color: AppColors.error, size: 16),
      const SizedBox(width: Sp.sm),
      Expanded(child: Text(message,
          style: const TextStyle(color: AppColors.error, fontSize: 13, fontFamily: 'SpaceGrotesk'))),
    ]),
  );
}

// ── Success banner ────────────────────────────────────────────
class SuccessBanner extends StatelessWidget {
  final String message;
  const SuccessBanner({super.key, required this.message});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: Sp.md, vertical: Sp.sm + 2),
    decoration: BoxDecoration(
      color: AppColors.successGlow,
      borderRadius: BorderRadius.circular(Rx.md),
      border: Border.all(color: AppColors.success.withOpacity(0.4)),
    ),
    child: Row(children: [
      const Icon(Icons.check_circle_outline_rounded, color: AppColors.success, size: 16),
      const SizedBox(width: Sp.sm),
      Expanded(child: Text(message,
          style: const TextStyle(color: AppColors.success, fontSize: 13, fontFamily: 'SpaceGrotesk'))),
    ]),
  );
}

// ── App card ──────────────────────────────────────────────────
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;
  final Color? borderColor;

  const AppCard({super.key, required this.child, this.padding, this.onTap, this.borderColor});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(Rx.lg),
      border: Border.all(color: borderColor ?? AppColors.border),
    ),
    child: onTap != null
        ? InkWell(onTap: onTap, borderRadius: BorderRadius.circular(Rx.lg),
            child: Padding(padding: padding ?? const EdgeInsets.all(Sp.md), child: child))
        : Padding(padding: padding ?? const EdgeInsets.all(Sp.md), child: child),
  );
}

// ── Status chip ───────────────────────────────────────────────
class StatusChip extends StatelessWidget {
  final String label;
  final Color color;

  const StatusChip({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
    decoration: BoxDecoration(
      color: color.withOpacity(0.12),
      borderRadius: BorderRadius.circular(Rx.round),
      border: Border.all(color: color.withOpacity(0.35)),
    ),
    child: Text(label.toUpperCase(),
        style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700,
            letterSpacing: 0.5, fontFamily: 'SpaceGrotesk')),
  );
}

// ── Section header ────────────────────────────────────────────
class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel({super.key, required this.text});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: Sp.sm),
    child: Text(text.toUpperCase(),
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600,
            color: AppColors.textMuted, letterSpacing: 1.4, fontFamily: 'SpaceGrotesk')),
  );
}

// ── Avatar ────────────────────────────────────────────────────
class AppAvatar extends StatelessWidget {
  final String initials;
  final double size;
  final bool isAdmin;

  const AppAvatar({super.key, required this.initials, this.size = 40, this.isAdmin = false});

  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: isAdmin ? AppColors.brandGradient : null,
      color: isAdmin ? null : AppColors.surface2,
      border: Border.all(color: AppColors.border),
    ),
    child: Center(child: Text(initials,
        style: TextStyle(color: AppColors.textPrimary,
            fontSize: size * 0.35, fontWeight: FontWeight.w700, fontFamily: 'SpaceGrotesk'))),
  );
}

// ── Icon box ──────────────────────────────────────────────────
class IconBox extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;

  const IconBox({super.key, required this.icon, required this.color, this.size = 40});

  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      color: color.withOpacity(0.12),
      borderRadius: BorderRadius.circular(size * 0.28),
    ),
    child: Icon(icon, color: color, size: size * 0.5),
  );
}

// ── Stat card ─────────────────────────────────────────────────
class StatCard extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color? color;

  const StatCard({super.key, required this.value, required this.label,
      required this.icon, this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.brand1;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Icon(icon, color: c, size: 20),
          Container(width: 8, height: 8,
              decoration: BoxDecoration(shape: BoxShape.circle, color: c)),
        ]),
        const SizedBox(height: Sp.sm),
        Text(value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700,
            color: AppColors.textPrimary, height: 1, fontFamily: 'SpaceGrotesk')),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textMuted,
            fontFamily: 'SpaceGrotesk')),
      ]),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? action;

  const EmptyState({super.key, required this.icon, required this.title,
      this.subtitle, this.action});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(Sp.xl),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 72, height: 72,
            decoration: BoxDecoration(color: AppColors.surface2,
                borderRadius: BorderRadius.circular(18)),
            child: Icon(icon, size: 32, color: AppColors.textMuted)),
        const SizedBox(height: Sp.lg),
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600,
            color: AppColors.textPrimary, fontFamily: 'SpaceGrotesk'),
            textAlign: TextAlign.center),
        if (subtitle != null) ...[
          const SizedBox(height: Sp.sm),
          Text(subtitle!, textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 14,
                  fontFamily: 'SpaceGrotesk')),
        ],
        if (action != null) ...[const SizedBox(height: Sp.lg), action!],
      ]),
    ),
  );
}

// ── App bar standard ──────────────────────────────────────────
PreferredSizeWidget appBar(String title, {
  List<Widget>? actions, Widget? leading, bool showLogo = false,
}) => AppBar(
  title: showLogo
      ? Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 26, height: 26,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(7),
                gradient: AppColors.brandGradient,
              ),
              child: const Icon(Icons.local_parking_rounded, color: Colors.white, size: 15)),
          const SizedBox(width: 8),
          const Text('Appertura'),
        ])
      : Text(title),
  actions: actions,
  leading: leading,
);
