// supabase/functions/generate-ble-token/index.ts
// Appertura — Edge Function de producción
// Genera token BLE seguro de 30 segundos para apertura de puerta

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0'

const ALLOWED_ORIGINS = [
  'https://app.appertura.app',
  'https://admin.appertura.app',
  'http://localhost:3000', // dev
  'http://localhost:8080', // flutter web dev
]

function corsHeaders(origin: string | null) {
  const allowed = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0]
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Max-Age': '86400',
  }
}

function json(data: unknown, status = 200, origin: string | null = null) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
  })
}

Deno.serve(async (req) => {
  const origin = req.headers.get('Origin')

  // CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders(origin) })
  }

  if (req.method !== 'POST') {
    return json({ error: 'METHOD_NOT_ALLOWED' }, 405, origin)
  }

  try {
    // Verificar JWT del usuario
    const authHeader = req.headers.get('Authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return json({ error: 'UNAUTHORIZED', message: 'Missing or invalid Authorization header' }, 401, origin)
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    )

    // Verificar usuario autenticado
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return json({ error: 'UNAUTHORIZED', message: 'Invalid token' }, 401, origin)
    }

    // Parsear body
    let body: { device_id?: string }
    try {
      body = await req.json()
    } catch {
      return json({ error: 'INVALID_BODY', message: 'Expected JSON body with device_id' }, 400, origin)
    }

    const { device_id } = body
    if (!device_id || typeof device_id !== 'string') {
      return json({ error: 'MISSING_DEVICE_ID' }, 400, origin)
    }

    // Llamar a función PostgreSQL que gestiona permisos + token
    const { data, error } = await supabase.rpc('generate_ble_token', {
      p_user_id: user.id,
      p_device_id: device_id,
    })

    if (error) {
      const code = error.message || 'UNKNOWN'
      if (code.includes('ACCESS_DENIED'))    return json({ error: 'ACCESS_DENIED' }, 403, origin)
      if (code.includes('USER_SUSPENDED'))   return json({ error: 'USER_SUSPENDED' }, 403, origin)
      if (code.includes('DEVICE_INACTIVE'))  return json({ error: 'DEVICE_INACTIVE' }, 403, origin)
      console.error('generate_ble_token error:', error)
      return json({ error: 'INTERNAL_ERROR' }, 500, origin)
    }

    if (!data || data.length === 0) {
      return json({ error: 'TOKEN_GENERATION_FAILED' }, 500, origin)
    }

    const result = data[0]
    return json({
      token:          result.token,
      token_id:       result.token_id,
      expires_at:     result.expires_at,
      relay_pulse_ms: result.relay_pulse_ms,
    }, 200, origin)

  } catch (err) {
    console.error('Unhandled exception:', err)
    return json({ error: 'INTERNAL_ERROR' }, 500, origin)
  }
})
