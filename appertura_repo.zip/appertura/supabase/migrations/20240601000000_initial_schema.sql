-- ================================================================
-- APPERTURA MVP — Schema PostgreSQL completo
-- Supabase · PostgreSQL 15
-- Ejecutar en: Supabase Dashboard → SQL Editor → Run
-- ================================================================

-- Extensiones
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ================================================================
-- TABLA: profiles
-- ================================================================
CREATE TABLE public.profiles (
  id              UUID        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email           TEXT        NOT NULL UNIQUE,
  full_name       TEXT,
  phone           TEXT,
  avatar_url      TEXT,
  role            TEXT        NOT NULL DEFAULT 'resident'
                              CHECK (role IN ('super_admin','admin','resident','guest')),
  community_id    UUID,                          -- FK añadida después
  is_active       BOOLEAN     NOT NULL DEFAULT true,
  suspended_at    TIMESTAMPTZ,
  suspended_reason TEXT,
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ================================================================
-- TABLA: communities
-- ================================================================
CREATE TABLE public.communities (
  id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        TEXT        NOT NULL,
  address     TEXT,
  city        TEXT,
  postal_code TEXT,
  country     TEXT        NOT NULL DEFAULT 'ES',
  admin_id    UUID        REFERENCES public.profiles(id),
  is_active   BOOLEAN     NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Ahora que communities existe, añadir FK a profiles
ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_community_id_fkey
  FOREIGN KEY (community_id) REFERENCES public.communities(id);

-- ================================================================
-- TABLA: parkings
-- ================================================================
CREATE TABLE public.parkings (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  community_id    UUID        REFERENCES public.communities(id),
  name            TEXT        NOT NULL,
  address         TEXT,
  city            TEXT,
  floors          INTEGER     DEFAULT 1,
  total_spots     INTEGER     DEFAULT 0,
  is_active       BOOLEAN     NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ================================================================
-- TABLA: parking_spaces (plazas individuales)
-- ================================================================
CREATE TABLE public.parking_spaces (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  parking_id      UUID        NOT NULL REFERENCES public.parkings(id) ON DELETE CASCADE,
  number          TEXT        NOT NULL,   -- "42", "B-07", "P1-003"
  label           TEXT,                   -- nombre descriptivo opcional
  floor           TEXT,
  is_active       BOOLEAN     NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(parking_id, number)
);

-- ================================================================
-- TABLA: devices (hardware Aparkao)
-- ================================================================
CREATE TABLE public.devices (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  device_id       TEXT        NOT NULL UNIQUE,  -- ID grabado en firmware
  ble_name        TEXT,                         -- APARKAO_XXXXXXXX
  ble_mac         TEXT,
  space_id        UUID        REFERENCES public.parking_spaces(id),
  firmware_version TEXT,
  relay_pulse_ms  INTEGER     NOT NULL DEFAULT 500,
  last_seen_at    TIMESTAMPTZ,
  is_active       BOOLEAN     NOT NULL DEFAULT true,
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ================================================================
-- TABLA: user_device_permissions
-- ================================================================
CREATE TABLE public.user_device_permissions (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  device_id       UUID        NOT NULL REFERENCES public.devices(id) ON DELETE CASCADE,
  permission_type TEXT        NOT NULL DEFAULT 'permanent'
                              CHECK (permission_type IN ('permanent','temporary','invitation')),
  valid_from      TIMESTAMPTZ,
  valid_until     TIMESTAMPTZ,
  max_uses        INTEGER,
  uses_count      INTEGER     NOT NULL DEFAULT 0,
  is_active       BOOLEAN     NOT NULL DEFAULT true,
  granted_by      UUID        REFERENCES public.profiles(id),
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, device_id)
);

-- ================================================================
-- TABLA: access_tokens (tokens BLE de 30 segundos)
-- ================================================================
CREATE TABLE public.access_tokens (
  id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  device_id   UUID        NOT NULL REFERENCES public.devices(id) ON DELETE CASCADE,
  token_hash  TEXT        NOT NULL UNIQUE,
  expires_at  TIMESTAMPTZ NOT NULL,
  used_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ================================================================
-- TABLA: access_logs (auditoría completa)
-- ================================================================
CREATE TABLE public.access_logs (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID        REFERENCES public.profiles(id),
  device_id       UUID        REFERENCES public.devices(id),
  space_id        UUID        REFERENCES public.parking_spaces(id),
  parking_id      UUID        REFERENCES public.parkings(id),
  community_id    UUID        REFERENCES public.communities(id),
  result          TEXT        NOT NULL
                              CHECK (result IN ('success','denied','error','timeout')),
  error_code      TEXT,
  error_message   TEXT,
  ble_rssi        INTEGER,
  access_method   TEXT        NOT NULL DEFAULT 'ble'
                              CHECK (access_method IN ('ble','remote','qr','admin')),
  token_id        UUID        REFERENCES public.access_tokens(id),
  device_firmware TEXT,
  app_version     TEXT,
  ip_address      INET,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ================================================================
-- TABLA: invitations
-- ================================================================
CREATE TABLE public.invitations (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  invited_by      UUID        NOT NULL REFERENCES public.profiles(id),
  invited_email   TEXT        NOT NULL,
  device_id       UUID        NOT NULL REFERENCES public.devices(id),
  permission_type TEXT        NOT NULL DEFAULT 'temporary',
  valid_from      TIMESTAMPTZ,
  valid_until     TIMESTAMPTZ,
  max_uses        INTEGER     DEFAULT 1,
  invitation_code TEXT        NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(16),'hex'),
  accepted_at     TIMESTAMPTZ,
  accepted_by     UUID        REFERENCES public.profiles(id),
  expires_at      TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ================================================================
-- ÍNDICES
-- ================================================================
CREATE INDEX idx_profiles_email          ON public.profiles(email);
CREATE INDEX idx_profiles_community      ON public.profiles(community_id);
CREATE INDEX idx_profiles_role           ON public.profiles(role);
CREATE INDEX idx_parkings_community      ON public.parkings(community_id);
CREATE INDEX idx_spaces_parking          ON public.parking_spaces(parking_id);
CREATE INDEX idx_devices_device_id       ON public.devices(device_id);
CREATE INDEX idx_devices_space           ON public.devices(space_id);
CREATE INDEX idx_permissions_user        ON public.user_device_permissions(user_id);
CREATE INDEX idx_permissions_device      ON public.user_device_permissions(device_id);
CREATE INDEX idx_permissions_active      ON public.user_device_permissions(is_active, valid_until);
CREATE INDEX idx_tokens_user_device      ON public.access_tokens(user_id, device_id);
CREATE INDEX idx_tokens_expires          ON public.access_tokens(expires_at);
CREATE INDEX idx_tokens_hash             ON public.access_tokens(token_hash);
CREATE INDEX idx_logs_user               ON public.access_logs(user_id);
CREATE INDEX idx_logs_device             ON public.access_logs(device_id);
CREATE INDEX idx_logs_community          ON public.access_logs(community_id);
CREATE INDEX idx_logs_created            ON public.access_logs(created_at DESC);
CREATE INDEX idx_logs_result             ON public.access_logs(result);

-- ================================================================
-- TRIGGERS: updated_at automático
-- ================================================================
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$;

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_communities_updated_at
  BEFORE UPDATE ON public.communities
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_parkings_updated_at
  BEFORE UPDATE ON public.parkings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_spaces_updated_at
  BEFORE UPDATE ON public.parking_spaces
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_devices_updated_at
  BEFORE UPDATE ON public.devices
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_permissions_updated_at
  BEFORE UPDATE ON public.user_device_permissions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ================================================================
-- TRIGGER: auto-crear profile al registrar usuario
-- ================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ================================================================
-- TRIGGER: actualizar last_login_at
-- ================================================================
CREATE OR REPLACE FUNCTION public.handle_user_login()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.last_sign_in_at IS DISTINCT FROM OLD.last_sign_in_at THEN
    UPDATE public.profiles SET last_login_at = NOW() WHERE id = NEW.id;
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_login
  AFTER UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_user_login();

-- ================================================================
-- FUNCIÓN: generate_ble_token (llamada desde Edge Function o RPC)
-- ================================================================
CREATE OR REPLACE FUNCTION public.generate_ble_token(
  p_user_id   UUID,
  p_device_id UUID
)
RETURNS TABLE(token TEXT, token_id UUID, expires_at TIMESTAMPTZ, relay_pulse_ms INTEGER)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_token       TEXT;
  v_hash        TEXT;
  v_token_id    UUID;
  v_expires     TIMESTAMPTZ;
  v_pulse       INTEGER;
  v_perm        RECORD;
BEGIN
  -- Verificar perfil activo
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = p_user_id AND is_active = true
  ) THEN
    RAISE EXCEPTION 'USER_SUSPENDED';
  END IF;

  -- Verificar permiso activo y válido
  SELECT * INTO v_perm
  FROM public.user_device_permissions
  WHERE user_id  = p_user_id
    AND device_id = p_device_id
    AND is_active = true
    AND (valid_from  IS NULL OR valid_from  <= NOW())
    AND (valid_until IS NULL OR valid_until  > NOW())
    AND (max_uses    IS NULL OR uses_count  < max_uses)
  LIMIT 1;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'ACCESS_DENIED';
  END IF;

  -- Obtener relay_pulse_ms del dispositivo
  SELECT d.relay_pulse_ms INTO v_pulse
  FROM public.devices d WHERE d.id = p_device_id AND d.is_active = true;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'DEVICE_INACTIVE';
  END IF;

  -- Generar token (32 bytes hex = 64 chars)
  v_token  := encode(gen_random_bytes(32), 'hex');
  v_hash   := encode(digest(v_token, 'sha256'), 'hex');
  v_expires := NOW() + INTERVAL '30 seconds';

  -- Limpiar tokens expirados del mismo usuario/dispositivo (housekeeping)
  DELETE FROM public.access_tokens
  WHERE user_id = p_user_id AND device_id = p_device_id AND expires_at < NOW();

  -- Insertar nuevo token
  INSERT INTO public.access_tokens (user_id, device_id, token_hash, expires_at)
  VALUES (p_user_id, p_device_id, v_hash, v_expires)
  RETURNING id INTO v_token_id;

  RETURN QUERY SELECT v_token, v_token_id, v_expires, v_pulse;
END; $$;

-- ================================================================
-- FUNCIÓN: log_access
-- ================================================================
CREATE OR REPLACE FUNCTION public.log_access(
  p_user_id      UUID,
  p_device_id    UUID,
  p_result       TEXT,
  p_ble_rssi     INTEGER  DEFAULT NULL,
  p_error_code   TEXT     DEFAULT NULL,
  p_app_version  TEXT     DEFAULT NULL,
  p_token_id     UUID     DEFAULT NULL
)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_log_id     UUID;
  v_space_id   UUID;
  v_parking_id UUID;
  v_comm_id    UUID;
BEGIN
  -- Obtener contexto del dispositivo
  SELECT d.space_id, ps.parking_id, pk.community_id
  INTO v_space_id, v_parking_id, v_comm_id
  FROM public.devices d
  LEFT JOIN public.parking_spaces ps ON ps.id = d.space_id
  LEFT JOIN public.parkings pk        ON pk.id = ps.parking_id
  WHERE d.id = p_device_id;

  INSERT INTO public.access_logs (
    user_id, device_id, space_id, parking_id, community_id,
    result, error_code, ble_rssi, app_version, token_id
  ) VALUES (
    p_user_id, p_device_id, v_space_id, v_parking_id, v_comm_id,
    p_result, p_error_code, p_ble_rssi, p_app_version, p_token_id
  ) RETURNING id INTO v_log_id;

  -- Si éxito: incrementar uses_count + actualizar last_seen_at
  IF p_result = 'success' THEN
    UPDATE public.user_device_permissions
    SET uses_count = uses_count + 1
    WHERE user_id = p_user_id AND device_id = p_device_id AND is_active = true;

    UPDATE public.devices SET last_seen_at = NOW() WHERE id = p_device_id;

    -- Marcar token como usado
    IF p_token_id IS NOT NULL THEN
      UPDATE public.access_tokens SET used_at = NOW() WHERE id = p_token_id;
    END IF;
  END IF;

  RETURN v_log_id;
END; $$;

-- ================================================================
-- FUNCIÓN: get_admin_stats (dashboard admin)
-- ================================================================
CREATE OR REPLACE FUNCTION public.get_admin_stats(p_community_id UUID DEFAULT NULL)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_result JSON;
BEGIN
  SELECT json_build_object(
    'total_users',        (SELECT COUNT(*) FROM profiles WHERE is_active = true
                            AND (p_community_id IS NULL OR community_id = p_community_id)),
    'total_devices',      (SELECT COUNT(*) FROM devices d
                            LEFT JOIN parking_spaces ps ON ps.id = d.space_id
                            LEFT JOIN parkings pk ON pk.id = ps.parking_id
                            WHERE d.is_active = true
                            AND (p_community_id IS NULL OR pk.community_id = p_community_id)),
    'accesses_today',     (SELECT COUNT(*) FROM access_logs
                            WHERE created_at >= CURRENT_DATE
                            AND (p_community_id IS NULL OR community_id = p_community_id)),
    'accesses_month',     (SELECT COUNT(*) FROM access_logs
                            WHERE created_at >= DATE_TRUNC('month', NOW())
                            AND (p_community_id IS NULL OR community_id = p_community_id)),
    'success_rate_30d',   (SELECT CASE WHEN COUNT(*) = 0 THEN 0
                            ELSE ROUND(COUNT(*) FILTER (WHERE result='success') * 100.0 / COUNT(*), 1)
                            END FROM access_logs
                            WHERE created_at >= NOW() - INTERVAL '30 days'
                            AND (p_community_id IS NULL OR community_id = p_community_id)),
    'active_permissions', (SELECT COUNT(*) FROM user_device_permissions
                            WHERE is_active = true
                            AND (valid_until IS NULL OR valid_until > NOW()))
  ) INTO v_result;
  RETURN v_result;
END; $$;

-- ================================================================
-- VISTAS
-- ================================================================
CREATE OR REPLACE VIEW public.v_access_logs AS
SELECT
  al.id,
  al.created_at,
  al.result,
  al.error_code,
  al.ble_rssi,
  al.access_method,
  p.full_name  AS user_name,
  p.email      AS user_email,
  d.device_id  AS device_hw_id,
  ps.number    AS space_number,
  ps.label     AS space_label,
  pk.name      AS parking_name,
  c.name       AS community_name
FROM public.access_logs al
LEFT JOIN public.profiles      p  ON p.id  = al.user_id
LEFT JOIN public.devices       d  ON d.id  = al.device_id
LEFT JOIN public.parking_spaces ps ON ps.id = al.space_id
LEFT JOIN public.parkings      pk ON pk.id = al.parking_id
LEFT JOIN public.communities   c  ON c.id  = al.community_id;

CREATE OR REPLACE VIEW public.v_user_devices AS
SELECT
  udp.id           AS permission_id,
  udp.user_id,
  udp.permission_type,
  udp.valid_from,
  udp.valid_until,
  udp.max_uses,
  udp.uses_count,
  udp.is_active    AS permission_active,
  d.id             AS device_uuid,
  d.device_id      AS device_hw_id,
  d.ble_name,
  d.relay_pulse_ms,
  d.is_active      AS device_active,
  d.last_seen_at,
  ps.number        AS space_number,
  ps.label         AS space_label,
  pk.id            AS parking_id,
  pk.name          AS parking_name,
  c.id             AS community_id,
  c.name           AS community_name
FROM public.user_device_permissions udp
JOIN public.devices       d  ON d.id  = udp.device_id
LEFT JOIN public.parking_spaces ps ON ps.id = d.space_id
LEFT JOIN public.parkings      pk ON pk.id = ps.parking_id
LEFT JOIN public.communities   c  ON c.id  = pk.community_id
WHERE udp.is_active = true
  AND d.is_active   = true;

-- ================================================================
-- ROW LEVEL SECURITY
-- ================================================================
ALTER TABLE public.profiles              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.communities           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parkings              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parking_spaces        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.devices               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_device_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.access_tokens         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.access_logs           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invitations           ENABLE ROW LEVEL SECURITY;

-- Helper: es admin o super_admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role IN ('admin','super_admin')
  );
$$;

-- Helper: comunidad del usuario actual
CREATE OR REPLACE FUNCTION public.my_community_id()
RETURNS UUID LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT community_id FROM public.profiles WHERE id = auth.uid();
$$;

-- profiles
CREATE POLICY "profiles: own"   ON public.profiles FOR ALL  USING (id = auth.uid());
CREATE POLICY "profiles: admin" ON public.profiles FOR ALL  USING (public.is_admin());

-- communities
CREATE POLICY "communities: member" ON public.communities FOR SELECT
  USING (id = public.my_community_id() OR public.is_admin());
CREATE POLICY "communities: admin"  ON public.communities FOR ALL USING (public.is_admin());

-- parkings
CREATE POLICY "parkings: member" ON public.parkings FOR SELECT
  USING (community_id = public.my_community_id() OR public.is_admin());
CREATE POLICY "parkings: admin"  ON public.parkings FOR ALL USING (public.is_admin());

-- parking_spaces
CREATE POLICY "spaces: member" ON public.parking_spaces FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.parkings pk
    WHERE pk.id = parking_spaces.parking_id
      AND (pk.community_id = public.my_community_id() OR public.is_admin())
  ));
CREATE POLICY "spaces: admin" ON public.parking_spaces FOR ALL USING (public.is_admin());

-- devices: usuario ve dispositivos a los que tiene permiso
CREATE POLICY "devices: authorized" ON public.devices FOR SELECT
  USING (
    public.is_admin() OR EXISTS (
      SELECT 1 FROM public.user_device_permissions udp
      WHERE udp.device_id = devices.id
        AND udp.user_id = auth.uid()
        AND udp.is_active = true
    )
  );
CREATE POLICY "devices: admin" ON public.devices FOR ALL USING (public.is_admin());

-- permissions
CREATE POLICY "permissions: own"   ON public.user_device_permissions FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "permissions: admin" ON public.user_device_permissions FOR ALL   USING (public.is_admin());

-- access_tokens
CREATE POLICY "tokens: own"   ON public.access_tokens FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "tokens: admin" ON public.access_tokens FOR ALL   USING (public.is_admin());

-- access_logs
CREATE POLICY "logs: own"   ON public.access_logs FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "logs: admin" ON public.access_logs FOR ALL   USING (public.is_admin());

-- invitations
CREATE POLICY "invitations: own"   ON public.invitations FOR SELECT USING (invited_by = auth.uid());
CREATE POLICY "invitations: admin" ON public.invitations FOR ALL   USING (public.is_admin());

-- ================================================================
-- GRANT acceso a funciones desde cliente anon/authenticated
-- ================================================================
GRANT EXECUTE ON FUNCTION public.generate_ble_token(UUID, UUID)   TO authenticated;
GRANT EXECUTE ON FUNCTION public.log_access(UUID,UUID,TEXT,INTEGER,TEXT,TEXT,UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_admin_stats(UUID)             TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin()                        TO authenticated;
GRANT SELECT  ON public.v_access_logs   TO authenticated;
GRANT SELECT  ON public.v_user_devices  TO authenticated;
