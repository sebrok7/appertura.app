-- ================================================================
-- APPERTURA — Seed de demostración
-- Ejecutar SOLO en entorno de desarrollo/staging, NUNCA en producción
-- ================================================================

-- Comunidad demo
INSERT INTO public.communities (id, name, address, city) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Comunitat Aparkao Demo', 'Carrer de la Prova 1', 'Barcelona')
ON CONFLICT DO NOTHING;

-- Parking demo
INSERT INTO public.parkings (id, community_id, name, address, city, total_spots) VALUES
  ('00000000-0000-0000-0000-000000000010', '00000000-0000-0000-0000-000000000001',
   'Parking Bloc A', 'Carrer de la Prova 1', 'Barcelona', 4)
ON CONFLICT DO NOTHING;

-- Plazas demo
INSERT INTO public.parking_spaces (id, parking_id, number, label, floor) VALUES
  ('00000000-0000-0000-0000-000000000020', '00000000-0000-0000-0000-000000000010', 'B-01', 'Plaza B-01', 'B1'),
  ('00000000-0000-0000-0000-000000000021', '00000000-0000-0000-0000-000000000010', 'B-02', 'Plaza B-02', 'B1'),
  ('00000000-0000-0000-0000-000000000022', '00000000-0000-0000-0000-000000000010', 'B-03', 'Plaza B-03', 'B1'),
  ('00000000-0000-0000-0000-000000000023', '00000000-0000-0000-0000-000000000010', 'B-04', 'Plaza B-04', 'B1')
ON CONFLICT DO NOTHING;

-- Dispositivos demo (Device IDs ficticios para desarrollo)
INSERT INTO public.devices (id, device_id, ble_name, space_id, relay_pulse_ms, firmware_version) VALUES
  ('00000000-0000-0000-0000-000000000030', 'DEV001', 'APARKAO_DEV001',
   '00000000-0000-0000-0000-000000000020', 500, '1.0.0'),
  ('00000000-0000-0000-0000-000000000031', 'DEV002', 'APARKAO_DEV002',
   '00000000-0000-0000-0000-000000000021', 500, '1.0.0')
ON CONFLICT DO NOTHING;

-- NOTA: Los usuarios se crean via Supabase Auth.
-- Tras registrarse, ejecutar para hacer admin:
-- UPDATE public.profiles SET role = 'admin' WHERE email = 'admin@example.com';
-- UPDATE public.profiles SET community_id = '00000000-0000-0000-0000-000000000001' WHERE email = 'admin@example.com';
